@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3 formation_planner.py
) else (
    python formation_planner.py
)
if errorlevel 1 (
    echo.
    echo Formation Planner could not start. Install Python 3 with tkinter.
    pause
)
