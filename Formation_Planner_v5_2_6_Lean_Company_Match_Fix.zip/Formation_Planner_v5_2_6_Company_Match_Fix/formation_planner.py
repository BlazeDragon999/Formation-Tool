#!/usr/bin/env python3
"""Formation Planner v5.2.5: classic v5.2.1 with separate attendance administration.

Default: 8 people across each group. Front-right is tallest.
Groups align side by side, with all front ranks on one straight line.

Python 3 + tkinter only. Records are stored in ~/FormationPlanner/roster.sqlite3,
including records created with earlier Formation Planner versions.
"""

from __future__ import annotations

import csv
import html
import sqlite3
import re
import zipfile
import posixpath
import xml.etree.ElementTree as ET
import tkinter as tk
import webbrowser
from dataclasses import dataclass
from admin_backend import AdminMixin
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

APP_DIR = Path.home() / "FormationPlanner"
DB_PATH = APP_DIR / "roster.sqlite3"
DEFAULT_GROUPS = {
    "A": "Alpha", "B": "Bravo", "C": "Charlie", "D": "Delta",
    "E": "Echo", "F": "Foxtrot", "G": "Golf", "H": "Hotel",
    "PIPE": "Pipe Band", "REG": "Regimental Staff",
}
ROLE_CHOICES = ["Member", "Leader", "Assistant Leader", "Formation", "CC", "XO"]
MODES = ["Ranks", "Single file", "Line abreast"]
SORT_MODES = ["Height only", "Class only", "Class then height"]
CLASS_CHOICES = ["1/c", "2/c", "3/c", "4/c", ""]
ALL_GROUPS = "All companies / groups"
OVERVIEW = "All groups | side-by-side blocks"
COLORS = ["#1c698b", "#3d7293", "#267a77", "#7659a4", "#965b3e",
          "#4c7c55", "#985b83", "#4b6a96", "#687488", "#6d7267"]


def clean(value: str) -> str:
    return " ".join(str(value).strip().split())


def height_from_parts(feet: int, inches: int) -> int:
    if feet < 0 or not (0 <= inches < 12) or feet * 12 + inches <= 0:
        raise ValueError("Height must be positive, with inches between 0 and 11.")
    return feet * 12 + inches


def show_height(inches: int) -> str:
    if inches <= 0:
        return "Not entered"
    feet, rest = divmod(inches, 12)
    return f"{feet}' {rest}\""


def parse_attendance(value: str) -> bool:
    value = clean(value).lower()
    if value in {"", "yes", "y", "true", "1", "present", "attending"}:
        return True
    if value in {"no", "n", "false", "0", "absent", "not attending"}:
        return False
    raise ValueError(f"Attendance must be Yes or No, not {value!r}.")


def in_ranks(role: str) -> bool:
    return clean(role).casefold() in {"", "member", "formation"}


@dataclass(frozen=True)
class Person:
    id: int
    name: str
    group: str
    height_inches: int
    attending: bool = True
    role: str = "Member"
    cadet_class: str = ""


@dataclass(frozen=True)
class Group:
    key: str
    name: str


@dataclass
class Formation:
    group: Group
    members: list[Person]
    leaders: list[Person]


def class_sort_key(value: str) -> tuple[int, int, str]:
    """Senior to junior (1/c to 4/c), then years ascending, then other classes.

    Unknown/blank class comes last. Handles `1/c`, `1c`, `Class of 2030`.
    """
    value = clean(value)
    if not value:
        return (3, 0, "")
    match = re.fullmatch(r"([1-4])\s*/?\s*c", value, re.I)
    if match:
        return (0, int(match.group(1)), "")
    match = re.fullmatch(r"(?:class\s+of\s+)?(20\d{2})", value, re.I)
    if match:
        return (1, int(match.group(1)), "")
    return (2, 0, value.casefold())


def ordered_members(members: list[Person], tallest_first: bool = True,
                    sort_mode: str = "Height only") -> list[Person]:
    """Class order is senior to junior; height is tallest to shortest by default."""
    if sort_mode not in SORT_MODES:
        raise ValueError(f"Unknown sort mode: {sort_mode}")
    height_factor = -1 if tallest_first else 1
    def key(p: Person):
        name = (p.name.casefold(), p.id)
        # Unmeasured cadets always sort last when height is used as a key.
        # Their provisional placement is alphabetical, never an invented height.
        height_key = (p.height_inches <= 0, height_factor * p.height_inches)
        if sort_mode == "Height only":
            return (*height_key, *name)
        if sort_mode == "Class only":
            return (*class_sort_key(p.cadet_class), *name)
        return (*class_sort_key(p.cadet_class), *height_key, *name)
    return sorted(members, key=key)


def make_rows(members: list[Person], mode: str = "Single file", per_row: int = 8,
              tallest_first: bool = True, sort_mode: str = "Height only") -> list[list[Person | None]]:
    """Per-group blocks, filled right-to-left, with front rows listed first."""
    if mode not in MODES:
        raise ValueError(f"Invalid formation style: {mode}")
    if per_row < 1:
        raise ValueError("People per rank must be at least 1.")
    people = ordered_members(members, tallest_first, sort_mode)
    if mode == "Single file":
        return [[p] for p in people]
    if mode == "Line abreast":
        return [list(reversed(people))] if people else []
    result: list[list[Person | None]] = []
    for start in range(0, len(people), per_row):
        chunk = people[start:start + per_row]
        result.append([None] * (per_row - len(chunk)) + list(reversed(chunk)))
    return result


def sections_for(people: list[Person], groups: list[Group], chosen_group: str | None) -> list[Formation]:
    result: list[Formation] = []
    for group in groups:
        if group.key in {"PIPE","FOOT","SUPPORT"}:  # Attendance/support categories are not marching formations.
            continue
        if chosen_group is not None and group.key != chosen_group:
            continue
        attending = [p for p in people if p.group == group.key and p.attending]
        members = [p for p in attending if in_ranks(p.role)]
        leaders = [p for p in attending if not in_ranks(p.role)]
        if attending or chosen_group is not None:
            result.append(Formation(group, members, leaders))
    return result


class Registry(AdminMixin):
    """Keeps the same data folder as versions 1 through 4."""

    def __init__(self, path: Path = DB_PATH):
        path = Path(path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA foreign_keys=ON")
        existing_group_table = self.conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='formation_groups'"
        ).fetchone() is not None
        with self.conn:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS cadets (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    company TEXT NOT NULL,
                    height_inches INTEGER NOT NULL,
                    role TEXT NOT NULL DEFAULT 'Member'
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL UNIQUE
                );
                CREATE TABLE IF NOT EXISTS attendance (
                    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                    cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                    attending INTEGER NOT NULL,
                    PRIMARY KEY(event_id, cadet_id)
                );
                CREATE TABLE IF NOT EXISTS formation_groups (
                    key TEXT PRIMARY KEY,
                    name TEXT NOT NULL COLLATE NOCASE UNIQUE
                );
            """)
            if not existing_group_table:
                # Seed only ONCE. Deleting starter groups must persist across launches.
                for key, name in DEFAULT_GROUPS.items():
                    self.conn.execute("INSERT OR IGNORE INTO formation_groups(key,name) VALUES (?,?)",
                                      (key, name))
            for (key,) in self.conn.execute("SELECT DISTINCT company FROM cadets"):
                if not self.conn.execute("SELECT 1 FROM formation_groups WHERE key=?", (key,)).fetchone():
                    self.conn.execute("INSERT OR IGNORE INTO formation_groups(key,name) VALUES (?,?)",
                                      (key, key))
            # Preserve existing v1-v4 records while adding an optional class.
            cols = {row[1] for row in self.conn.execute("PRAGMA table_info(cadets)")}
            if "cadet_class" not in cols:
                self.conn.execute("ALTER TABLE cadets ADD COLUMN cadet_class TEXT NOT NULL DEFAULT ''")
            self.conn.execute("INSERT OR IGNORE INTO events(name) VALUES ('Current Event')")
        if not self.conn.execute("SELECT 1 FROM sqlite_master WHERE name='cadet_heights'").fetchone():
            if self.conn.execute('SELECT COUNT(*) FROM cadets').fetchone()[0]:
                self.backup_database('before_v5_2_2_migration')
        self.init_admin_schema()
        # One-time migration from 5.2.1/5.2.2: use cadet-selected event statuses,
        # preserving any old explicit No as Excused. Save a complete DB backup.
        with self.conn:
            self.conn.execute('''CREATE TABLE IF NOT EXISTS app_migrations (
                   version TEXT PRIMARY KEY, applied_at TEXT NOT NULL)''')
        updated=self.conn.execute("SELECT 1 FROM app_migrations WHERE version='5.2.3'").fetchone()
        if not updated:
            if self.conn.execute('SELECT COUNT(*) FROM cadets').fetchone()[0]:
                self.backup_database('before_v5_2_3_simplification')
            for (event_id,) in self.conn.execute('SELECT id FROM events').fetchall():
                self.reconcile_event(event_id)
            with self.conn:
                self.conn.execute('INSERT INTO app_migrations(version,applied_at) VALUES (?,?)',
                                  ('5.2.3',datetime.now().isoformat(timespec='seconds')))

    def close(self) -> None:
        self.conn.close()

    def groups(self) -> list[Group]:
        return [Group(k, n) for k, n in self.conn.execute(
            "SELECT key,name FROM formation_groups ORDER BY name COLLATE NOCASE")]

    def resolve_group(self, value: str, create: bool = False) -> str:
        value = clean(value)
        if not value:
            raise ValueError("Group/company is required.")
        compare = value.casefold()
        for group in self.groups():
            if compare in {group.key.casefold(), group.name.casefold(),
                           f"{group.key} - {group.name}".casefold()}:
                return group.key
        if create:
            return self.add_group(value)
        raise ValueError(f"Unknown group: {value}. Add it using Manage Groups.")

    def add_group(self, name: str) -> str:
        name = clean(name)
        if not name:
            raise ValueError("Enter a group name.")
        if any(g.name.casefold() == name.casefold() for g in self.groups()):
            raise ValueError(f"A group named {name} already exists.")
        # Stable opaque ID means renaming a group doesn't affect roster or attendance.
        next_num = 1
        while self.conn.execute("SELECT 1 FROM formation_groups WHERE key=?", (f"U{next_num:04}",)).fetchone():
            next_num += 1
        key = f"U{next_num:04}"
        if self.conn.in_transaction:
            self.conn.execute("INSERT INTO formation_groups(key,name) VALUES (?,?)", (key, name))
        else:
            with self.conn:
                self.conn.execute("INSERT INTO formation_groups(key,name) VALUES (?,?)", (key, name))
        return key

    def rename_group(self, key: str, name: str) -> None:
        name = clean(name)
        if not name:
            raise ValueError("Enter a group name.")
        with self.conn:
            self.conn.execute("UPDATE formation_groups SET name=? WHERE key=?", (name, key))

    def remove_group(self, key: str) -> None:
        count = self.conn.execute("SELECT COUNT(*) FROM cadets WHERE company=?", (key,)).fetchone()[0]
        if count:
            raise ValueError(f"This group still has {count} registered members. Move or delete them first.")
        with self.conn:
            self.conn.execute("DELETE FROM formation_groups WHERE key=?", (key,))

    def events(self) -> list[tuple[int, str]]:
        return self.conn.execute("SELECT id,name FROM events ORDER BY id").fetchall()

    def new_event(self, name: str) -> int:
        name = clean(name)
        if not name:
            raise ValueError("Enter an event name.")
        with self.conn:
            return self.conn.execute("INSERT INTO events(name) VALUES (?)", (name,)).lastrowid

    def roster(self, event_id: int) -> list[Person]:
        rows = self.conn.execute("""
            SELECT c.id,c.name,c.company,c.height_inches,COALESCE(a.attending,1),c.role,c.cadet_class
            FROM cadets c LEFT JOIN attendance a
              ON a.cadet_id=c.id AND a.event_id=?
            ORDER BY c.name COLLATE NOCASE, c.id
        """, (event_id,)).fetchall()
        return [Person(i, n, g, h, bool(a), r, cls) for i, n, g, h, a, r, cls in rows]

    def save_person(self, person_id: int | None, name: str, group: str, height_inches: int,
                    role: str, attending: bool, event_id: int, cadet_class: str = "") -> int:
        with self.conn:
            return self._save_person_uncommitted(person_id, name, group, height_inches,
                                                 role, attending, event_id, cadet_class)

    def _save_person_uncommitted(self, person_id: int | None, name: str, group: str,
                                 height_inches: int, role: str, attending: bool,
                                 event_id: int, cadet_class: str = "", verification_hint: str = "Manual") -> int:
        name, role, cadet_class = clean(name), clean(role) or "Member", clean(cadet_class)
        if not name:
            raise ValueError("A name is required.")
        if height_inches < 0:
            raise ValueError("Height cannot be negative.")
        if group not in {g.key for g in self.groups()}:
            raise ValueError("Choose an existing group.")
        if person_id is None:
            person_id = self.conn.execute(
                "INSERT INTO cadets(name,company,height_inches,role,cadet_class) VALUES (?,?,?,?,?)",
                (name, group, height_inches, role, cadet_class)).lastrowid
        else:
            cur = self.conn.execute(
                "UPDATE cadets SET name=?,company=?,height_inches=?,role=?,cadet_class=? WHERE id=?",
                (name, group, height_inches, role, cadet_class, person_id))
            if cur.rowcount == 0:
                raise ValueError("Member no longer exists.")
        current_status=self.conn.execute('SELECT status FROM event_submissions WHERE event_id=? AND cadet_id=?',
                                         (event_id,person_id)).fetchone()
        if current_status is None or (current_status[0]=='Attending')!=bool(attending):
            self.conn.execute('''INSERT INTO event_submissions(event_id,cadet_id,status,support_role,updated_at)
                 VALUES(?,?,?,'',?) ON CONFLICT(event_id,cadet_id) DO UPDATE SET status=excluded.status,
                 support_role=excluded.support_role,updated_at=excluded.updated_at''',
                (event_id,person_id,'Attending' if attending else 'Excused',datetime.now().isoformat(timespec='seconds')))
        self._set_attendance(event_id, person_id, attending)
        # v5.2.1 still exposes height editing in its familiar member editor.  Mirror
        # that value into the separate admin height table without losing verification
        # when the measurement has not changed.
        old = self.conn.execute('SELECT height_inches,verification FROM cadet_heights WHERE cadet_id=?',
                                (person_id,)).fetchone()
        if old is None or old[0] != height_inches:
            self.conn.execute("INSERT INTO cadet_heights(cadet_id,height_inches,verification,updated_at) "
                              "VALUES(?,?,?,?) ON CONFLICT(cadet_id) DO UPDATE SET "
                              "height_inches=excluded.height_inches,verification=excluded.verification,updated_at=excluded.updated_at",
                (person_id,height_inches,verification_hint if height_inches else 'Unverified',datetime.now().isoformat(timespec='seconds')))
        return person_id

    def _set_attendance(self, event_id: int, person_id: int, attending: bool) -> None:
        self.conn.execute("""
            INSERT INTO attendance(event_id,cadet_id,attending) VALUES (?,?,?)
            ON CONFLICT(event_id,cadet_id) DO UPDATE SET attending=excluded.attending
        """, (event_id, person_id, int(attending)))

    def set_attendance(self, event_id: int, person_id: int, attending: bool) -> None:
        self.set_submitted_status(event_id, person_id, 'Attending' if attending else 'Excused')

    def backup_database(self, reason: str = "manual") -> Path:
        """Create a transactionally consistent copy of the live SQLite database.

        Do not copy the .sqlite3 file with shutil: SQLite may be in WAL mode.
        sqlite3.backup() captures the real, committed database including events,
        group assignments, attendance, and classes.
        """
        if self.conn.in_transaction:
            raise RuntimeError("Cannot back up while a write transaction is active.")
        folder = self.path.parent / "backups"
        folder.mkdir(parents=True, exist_ok=True)
        slug = re.sub(r"[^a-z0-9_]+", "_", reason.lower()).strip("_") or "manual"
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        dest = folder / f"roster_before_{slug}_{stamp}.sqlite3"
        # For an extremely unlikely microsecond collision, don't overwrite a backup.
        serial = 2
        while dest.exists():
            dest = folder / f"roster_before_{slug}_{stamp}_{serial}.sqlite3"
            serial += 1
        backup = None
        try:
            backup = sqlite3.connect(dest)
            self.conn.backup(backup)
        except Exception:
            if backup is not None:
                backup.close()
            dest.unlink(missing_ok=True)
            raise
        else:
            backup.close()
        return dest

    def delete_people(self, person_ids: list[int]) -> tuple[int, Path | None]:
        """Remove selected members across all events; preserve everyone else."""
        ids = sorted(set(int(value) for value in person_ids))
        if not ids:
            return 0, None
        placeholders = ",".join("?" for _ in ids)
        existing = self.conn.execute(
            f"SELECT COUNT(*) FROM cadets WHERE id IN ({placeholders})", ids
        ).fetchone()[0]
        if not existing:
            return 0, None
        backup = self.backup_database("selected_members")
        with self.conn:
            removed = self.conn.execute(
                f"DELETE FROM cadets WHERE id IN ({placeholders})", ids
            ).rowcount
        return removed, backup

    def delete_person(self, person_id: int) -> tuple[int, Path | None]:
        return self.delete_people([person_id])

    def clear_group(self, key: str) -> tuple[int, Path | None]:
        """Delete members of one group, including attendance across events."""
        if key not in {g.key for g in self.groups()}:
            raise ValueError("Choose an existing company or group.")
        count = self.conn.execute(
            "SELECT COUNT(*) FROM cadets WHERE company=?", (key,)
        ).fetchone()[0]
        if not count:
            return 0, None
        backup = self.backup_database("company_" + key)
        with self.conn:
            removed = self.conn.execute("DELETE FROM cadets WHERE company=?", (key,)).rowcount
        return removed, backup

    def clear_roster(self) -> tuple[int, Path | None]:
        """Delete all people but keep custom groups and event names."""
        count = self.conn.execute("SELECT COUNT(*) FROM cadets").fetchone()[0]
        if not count:
            return 0, None
        backup = self.backup_database("all_members")
        with self.conn:
            removed = self.conn.execute("DELETE FROM cadets").rowcount
        return removed, backup

    def reset_database(self) -> tuple[int, Path]:
        """Fully reset the registry, retaining a complete pre-reset backup."""
        count = self.conn.execute("SELECT COUNT(*) FROM cadets").fetchone()[0]
        backup = self.backup_database("factory_reset")
        with self.conn:
            self.conn.execute("DELETE FROM cadets")
            self.conn.execute("DELETE FROM attendance")
            self.conn.execute("DELETE FROM events")
            self.conn.execute("DELETE FROM formation_groups")
            self.conn.executemany("INSERT INTO formation_groups(key,name) VALUES (?,?)",
                                  DEFAULT_GROUPS.items())
            self.conn.execute("INSERT INTO events(name) VALUES ('Current Event')")
        return count, backup

    def import_rows(self, rows: list[dict[str, str]], event_id: int,
                    default_group: str | None = None) -> tuple[int, int]:
        """Accepts either Group or Company and optional ID for reliable transfers.

        Auto-creates unfamiliar named groups. All changes rolled back on bad data.
        """
        added = updated = 0
        with self.conn:
            # Begin immediately so auto-created groups and rows roll back together.
            self.conn.execute("BEGIN")
            for lineno, original in enumerate(rows, 2):
                fields = {clean(k).lower().replace(" ", "_"): clean(v or "")
                          for k, v in original.items() if k is not None}
                try:
                    name = fields.get("name", "")
                    if not name:
                        raise ValueError("Missing Name")
                    imported_group = fields.get("group") or fields.get("company") or default_group or ""
                    membership = None
                    if clean(imported_group).casefold() in ('pipe band','pipe','football','game support') and fields.get('home_company'):
                        membership = {'pipe band':'Pipe Band','pipe':'Pipe Band','football':'Football',
                                      'game support':'Game Support'}[clean(imported_group).casefold()]
                        imported_group = fields['home_company']
                    group = self.resolve_group(imported_group, create=True)
                    if fields.get("height_inches"):
                        height = int(fields["height_inches"])
                        if height < 0:
                            raise ValueError("Height cannot be negative")
                    elif fields.get("feet") or fields.get("inches"):
                        height = height_from_parts(int(fields.get("feet") or "0"),
                                                   int(fields.get("inches") or "0"))
                    else:
                        # Unknown measurements are saved as 0 until filled in.
                        height = 0
                    attendance = parse_attendance(fields.get("attending", "Yes"))
                    role = fields.get("role") or "Member"
                    cadet_class = fields.get("class") or fields.get("cadet_class") or ""
                    person_id = None
                    if fields.get("id"):
                        person_id = int(fields["id"])
                        if not self.conn.execute("SELECT 1 FROM cadets WHERE id=?", (person_id,)).fetchone():
                            raise ValueError(f"ID {person_id} does not exist; leave ID blank for new people")
                    else:
                        match = self.conn.execute(
                            "SELECT id FROM cadets WHERE name=? COLLATE NOCASE AND company=? ORDER BY id LIMIT 1",
                            (name, group)).fetchone()
                        if match:
                            person_id = match[0]
                        else:
                            # A unique full-name + class match supports restoring a
                            # former Pipe Band cadet's home company without duplication.
                            matches = self.conn.execute('''SELECT id FROM cadets WHERE name=? COLLATE NOCASE AND cadet_class=?''',
                                                         (name,cadet_class)).fetchall()
                            if len(matches) == 1:
                                person_id = matches[0][0]
                            elif len(matches)>1:
                                raise ValueError(f'Ambiguous cadet identity: {name} ({cadet_class}); use Cadet ID')
                    if person_id is not None and height == 0:
                        # Importing a blank spreadsheet cell must not erase a
                        # height already entered in the local registry.
                        prior = self.conn.execute(
                            "SELECT height_inches FROM cadets WHERE id=?", (person_id,)).fetchone()
                        if prior is not None:
                            height = prior[0]
                    if person_id is None:
                        self._save_person_uncommitted(None, name, group, height, role, attendance, event_id, cadet_class,
                                                      fields.get('height_verification') or 'Legacy')
                        added += 1
                    else:
                        self._save_person_uncommitted(person_id, name, group, height, role, attendance, event_id, cadet_class,
                                                      fields.get('height_verification') or 'Legacy')
                        updated += 1
                    if membership:
                        target = person_id if person_id is not None else self.conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                        self.conn.execute('INSERT OR IGNORE INTO memberships(cadet_id,category,role) VALUES (?,?,?)',
                                          (target,membership,''))
                except (ValueError, KeyError, sqlite3.Error) as exc:
                    raise ValueError(f"CSV line {lineno}: {exc}") from exc
        return added, updated


def export_roster(path: Path, people: list[Person], names: dict[str, str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["ID", "Name", "Group", "Class", "Feet", "Inches", "Attending", "Role"])
        for p in people:
            f, inch = divmod(p.height_inches, 12) if p.height_inches else ("", "")
            writer.writerow([p.id, p.name, names[p.group], p.cadet_class, f, inch,
                             "Yes" if p.attending else "No", p.role])


def export_positions(path: Path, formations: list[Formation], event: str,
                     mode: str, per_row: int, tallest_first: bool,
                     sort_mode: str = "Height only") -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Event", "Group", "Style", "Row (1=Front)", "Column (1=Left)",
                    "Position from Right", "Sort Order", "Name", "Class", "Height", "Role", "ID"])
        for formation in formations:
            sort_order = ordered_members(formation.members, tallest_first, sort_mode)
            priority = {p.id: i + 1 for i, p in enumerate(sort_order)}
            for rowno, line in enumerate(make_rows(formation.members, mode, per_row, tallest_first, sort_mode), 1):
                for colno, person in enumerate(line, 1):
                    if person is None:
                        continue
                    w.writerow([event, formation.group.name, mode, rowno, colno,
                                len(line) - colno + 1, priority[person.id], person.name, person.cadet_class,
                                show_height(person.height_inches), person.role, person.id])
            for person in formation.leaders:
                w.writerow([event, formation.group.name, "Separate leader", "", "", "", "",
                            person.name, person.cadet_class, show_height(person.height_inches), person.role, person.id])


def export_printable(path: Path, formations: list[Formation], event: str,
                     mode: str, per_row: int, tallest_first: bool,
                     sort_mode: str = "Height only") -> None:
    e = html.escape
    def label(p: Person) -> str:
        return (f'<div class="member"><div class="name">{e(p.name)}</div>'
                f'<div class="height">{e(p.cadet_class or "Unassigned")} | {e(show_height(p.height_inches))}</div></div>')
    css = """
    body{background:#f5f7fa;color:#15324b;font:14px Arial,sans-serif;margin:28px}
    h1{margin-bottom:5px}p.subtitle{color:#557084;margin:0 0 20px}
    .overview{display:flex;align-items:flex-start;flex-wrap:wrap;gap:16px}
    section{background:white;border:1px solid #d5e0e7;border-radius:9px;padding:13px;break-inside:avoid;max-width:100%}
    h2{margin:0;padding-bottom:10px;border-bottom:2px solid #dce9f1;font-size:17px}
    .leaders{font-size:12px;margin:10px 0;color:#486279;max-width:650px}
    .row{display:flex;gap:5px;margin-top:8px;justify-content:space-between}
    .member{box-sizing:border-box;flex:1;min-width:72px;max-width:135px;background:#ebf4fa;border:1px solid #c5dce9;border-radius:7px;padding:7px 3px;text-align:center}
    .empty{box-sizing:border-box;flex:1;min-width:72px;max-width:135px;border:1px dashed #dee5ec;border-radius:7px}
    .name{font-weight:bold;overflow-wrap:anywhere}.height{margin-top:4px;color:#54718a;font-size:12px}
    .front{font-size:12px;font-weight:bold;color:#286587;margin:12px 0 8px;text-align:center}
    .none{color:#78909e;font-style:italic}small{color:#60798d}
    @page{size:landscape;margin:8mm}
    @media print{body{margin:8mm;background:white}section{border-color:#9eaebb;max-width:none}.overview{gap:12px}}
    """
    parts = [f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
             f'<title>Formation: {e(event)}</title><style>{css}</style></head><body>',
             f'<h1>Formation Planner</h1><p class="subtitle">{e(event)} | {e(mode)} | '
             f'{e(sort_mode)} | {"Tallest first" if tallest_first else "Shortest first"} | Groups sorted independently</p>',
             '<div class="front">↑ FRONT / DIRECTION OF FACING ↑</div><div class="overview">']
    for sec in formations:
        parts.append(f'<section><h2>{e(sec.group.name)} <small>({len(sec.members)} in formation)</small></h2>')
        if sec.leaders:
            parts.append('<div class="leaders">Separate roles: ' + '; '.join(
                f'{e(p.role)}: {e(p.name)}' for p in sec.leaders) + '</div>')
        rows = make_rows(sec.members, mode, per_row, tallest_first, sort_mode)
        if not rows:
            parts.append('<p class="none">No attending members in formation.</p>')
        for row in rows:
            parts.append('<div class="row">' + ''.join(label(p) if p else '<div class="empty"></div>'
                                                        for p in row) + '</div>')
        parts.append('</section>')
    if not formations:
        parts.append('<p class="none">No attending members for this selection.</p>')
    parts.append('</div></body></html>')
    path.write_text('\n'.join(parts), encoding='utf-8')


def read_company_workbook(path: Path) -> list[dict[str, str]]:
    """Read plain XLSX cells from named company sheets, no third-party package.

    The workbook has one tab per company; the sheet title supplies Group.
    Rows before a `Name` header are ignored. Blank roster rows are ignored.
    Formula evaluation is not supported; enter values in the editable cells.
    """
    main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel_ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    pack_rel = "http://schemas.openxmlformats.org/package/2006/relationships"
    def q(n): return "{" + main + "}" + n
    rows_out: list[dict[str, str]] = []
    with zipfile.ZipFile(path) as z:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            shared = ["".join(t.text or "" for t in si.iter(q("t"))) for si in root.findall(q("si"))]
        root = ET.fromstring(z.read("xl/workbook.xml"))
        relroot = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        relationships = {r.attrib["Id"]: r.attrib["Target"] for r in relroot.findall("{"+pack_rel+"}Relationship")}
        for sheet in root.find(q("sheets")):
            title = sheet.attrib["name"]
            if title.casefold() in {"instructions", "read me", "help", "summary"}:
                continue
            target = relationships[sheet.attrib["{" + rel_ns + "}id"]]
            location = (target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target)))
            if location not in z.namelist():
                raise ValueError(f"Spreadsheet sheet '{title}' cannot be read.")
            sheetroot = ET.fromstring(z.read(location))
            header = None
            for row in sheetroot.iter(q("row")):
                values: dict[str, str] = {}
                for cell in row.findall(q("c")):
                    match = re.match(r"([A-Z]+)", cell.get("r", ""))
                    if not match:
                        continue
                    col = match.group(1)
                    typ = cell.get("t")
                    raw = cell.find(q("v"))
                    if typ == "inlineStr":
                        inline = cell.find(q("is"))
                        value = "".join(t.text or "" for t in inline.iter(q("t"))) if inline is not None else ""
                    elif raw is None:
                        value = ""
                    elif typ == "s":
                        value = shared[int(raw.text or "0")]
                    else:
                        value = raw.text or ""
                    values[col] = clean(value)
                if header is None:
                    if any(v.casefold() == "name" for v in values.values()):
                        header = {c: v for c, v in values.items() if v}
                    continue
                fields = {title: values.get(col, "") for col, title in header.items()}
                if not any(fields.values()):
                    continue
                if not fields.get("Group") and not fields.get("Company"):
                    fields["Group"] = title
                rows_out.append(fields)
    if not rows_out:
        raise ValueError("No roster data found. Enter names below the column headers on company tabs.")
    return rows_out


def export_company_roster(path: Path, people: list[Person]) -> None:
    """Excel-friendly, one-company CSV. The company is chosen on import."""
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["ID", "Name", "Class", "Feet", "Inches", "Attending", "Role"])
        for p in people:
            ft, inch = divmod(p.height_inches, 12) if p.height_inches else ("", "")
            w.writerow([p.id, p.name, p.cadet_class, ft, inch,
                        "Yes" if p.attending else "No", p.role])


class GroupManager(tk.Toplevel):
    def __init__(self, parent: "FormationApp"):
        super().__init__(parent)
        self.app = parent
        self.title("Manage Groups")
        self.geometry("460x450")
        self.minsize(400, 320)
        self.transient(parent)
        frame = ttk.Frame(self, padding=15)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Groups, companies, teams, or squads", style="Section.TLabel").pack(anchor="w")
        ttk.Label(frame, text="Create or rename groups freely. Each sorts independently.").pack(anchor="w", pady=(3,10))
        table_frame = ttk.Frame(frame)
        table_frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table_frame, show="headings", columns=("name","count"), selectmode="browse")
        self.tree.heading("name", text="Group name")
        self.tree.heading("count", text="Registered members")
        self.tree.column("name", width=265)
        self.tree.column("count", width=125, anchor="center")
        self.tree.pack(fill="both", expand=True)
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(12,0))
        ttk.Button(buttons, text="+ Add", command=self.add).pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Rename", command=self.rename).pack(side="left", padx=(0,8))
        ttk.Button(buttons, text="Delete empty", command=self.delete).pack(side="left")
        self.reload()

    def reload(self):
        self.tree.delete(*self.tree.get_children())
        counts = {k: n for k,n in self.app.db.conn.execute(
            "SELECT company,COUNT(*) FROM cadets GROUP BY company")}
        for group in self.app.db.groups():
            self.tree.insert("", "end", iid=group.key, values=(group.name, counts.get(group.key, 0)))
        self.app.reload_groups()

    def selected(self):
        selected = self.tree.selection()
        return selected[0] if selected else None

    def add(self):
        name = simpledialog.askstring("Add Group", "New group name:", parent=self)
        if name is None:
            return
        try:
            key = self.app.db.add_group(name)
        except (ValueError, sqlite3.IntegrityError) as exc:
            messagebox.showerror("Could not add group", str(exc), parent=self)
            return
        self.reload()
        self.tree.selection_set(key)

    def rename(self):
        key = self.selected()
        if key is None:
            messagebox.showinfo("Select group", "Select a group first.", parent=self)
            return
        old = next(g.name for g in self.app.db.groups() if g.key == key)
        name = simpledialog.askstring("Rename Group", "New name:", initialvalue=old, parent=self)
        if name is None:
            return
        try:
            self.app.db.rename_group(key, name)
        except (ValueError, sqlite3.IntegrityError) as exc:
            messagebox.showerror("Could not rename group", str(exc), parent=self)
            return
        self.reload()
        self.tree.selection_set(key)

    def delete(self):
        key = self.selected()
        if key is None:
            return
        name = next(g.name for g in self.app.db.groups() if g.key == key)
        if not messagebox.askyesno("Delete Group", f"Delete empty group '{name}'?", parent=self):
            return
        try:
            self.app.db.remove_group(key)
        except ValueError as exc:
            messagebox.showerror("Cannot delete group", str(exc), parent=self)
            return
        self.reload()


class RosterManager(tk.Toplevel):
    """Safe bulk roster deletion with clear scopes and automatic backups."""

    def __init__(self, parent: "FormationApp"):
        super().__init__(parent)
        self.app = parent
        self.title("Manage Roster | Backups and Cleanup")
        sh = self.winfo_screenheight()
        self.geometry(f"630x{min(630, max(520, sh - 115))}")
        self.minsize(555, min(595, max(500, sh - 130)))
        self.transient(parent)
        # Keep every cleanup option accessible on displays with little vertical room.
        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.scroll_canvas = tk.Canvas(holder, bg="#f2f6f9", highlightthickness=0)
        scrollbar = ttk.Scrollbar(holder, orient="vertical", command=self.scroll_canvas.yview)
        self.scroll_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.scroll_canvas.pack(side="left", fill="both", expand=True)
        frame = ttk.Frame(self.scroll_canvas, padding=18)
        inner_id = self.scroll_canvas.create_window((0, 0), window=frame, anchor="nw")
        frame.bind("<Configure>", lambda event: self.scroll_canvas.configure(
            scrollregion=self.scroll_canvas.bbox("all")))
        self.scroll_canvas.bind("<Configure>", lambda event: self.scroll_canvas.itemconfigure(
            inner_id, width=event.width))
        ttk.Label(frame, text="Manage roster", style="Heading.TLabel").pack(anchor="w")
        ttk.Label(frame, text="All removal options affect every event, not just the current one.",
                  foreground="#725124").pack(anchor="w", pady=(5, 12))

        self.selection_label = tk.StringVar()
        self.count_label = tk.StringVar()
        self.group_name = tk.StringVar(value=parent.roster_scope_var.get())
        if self.group_name.get() == ALL_GROUPS or self.group_name.get() not in parent.group_map:
            self.group_name.set(next(iter(parent.group_map), ""))
        self.company_count_label = tk.StringVar()

        selected_frame = ttk.LabelFrame(frame, text="1. Selected people", padding=12)
        selected_frame.pack(fill="x", pady=5)
        ttk.Label(selected_frame, textvariable=self.selection_label).pack(anchor="w", pady=(0, 7))
        ttk.Button(selected_frame, text="Delete selected people",
                   command=self.delete_selected).pack(anchor="w")
        ttk.Label(selected_frame, text="Tip: Ctrl+click or Shift+click multiple roster rows before opening this window.",
                  foreground="#557286").pack(anchor="w", pady=(7, 0))

        group_frame = ttk.LabelFrame(frame, text="2. One company or group", padding=12)
        group_frame.pack(fill="x", pady=5)
        group_line = ttk.Frame(group_frame)
        group_line.pack(fill="x")
        self.company_combo = ttk.Combobox(group_line, textvariable=self.group_name,
                                          state="readonly", values=list(parent.group_map), width=25)
        self.company_combo.pack(side="left")
        self.company_combo.bind("<<ComboboxSelected>>", lambda *_: self.update_counts())
        ttk.Label(group_line, textvariable=self.company_count_label).pack(side="left", padx=(12, 0))
        ttk.Button(group_frame, text="Clear this company",
                   command=self.clear_company).pack(anchor="w", pady=(9, 0))

        all_frame = ttk.LabelFrame(frame, text="3. All members or complete reset", padding=12)
        all_frame.pack(fill="x", pady=5)
        ttk.Label(all_frame, textvariable=self.count_label).pack(anchor="w")
        ttk.Button(all_frame, text="Clear all people (keep groups and events)",
                   command=self.clear_everyone).pack(anchor="w", pady=(8, 5))
        ttk.Button(all_frame, text="Reset entire database to defaults",
                   command=self.reset_all).pack(anchor="w")
        ttk.Label(all_frame, text="Full reset also removes custom groups and extra events.",
                  foreground="#725124").pack(anchor="w", pady=(5, 0))

        ttk.Label(frame, text=f"Automatic database backups: {parent.db.path.parent / 'backups'}",
                  foreground="#244d68", wraplength=570).pack(anchor="w", pady=(9, 0))
        self.update_counts()

    def selected_ids(self) -> list[int]:
        return [int(row) for row in self.app.tree.selection() if int(row) in self.app.by_id]

    def update_counts(self) -> None:
        ids = self.selected_ids()
        self.selection_label.set(f"{len(ids)} selected in the roster table")
        total = self.app.db.conn.execute("SELECT COUNT(*) FROM cadets").fetchone()[0]
        self.count_label.set(f"{total} members currently registered")
        key = self.app.group_map.get(self.group_name.get())
        count = self.app.db.conn.execute(
            "SELECT COUNT(*) FROM cadets WHERE company=?", (key,)
        ).fetchone()[0] if key else 0
        self.company_count_label.set(f"{count} members")

    def finish(self, count: int, backup: Path | None, detail: str, reset: bool = False) -> None:
        if reset:
            self.app.event_id = self.app.db.events()[0][0]
            self.app.roster_scope_var.set(ALL_GROUPS)
            self.app.view_var.set(OVERVIEW)
            self.app.load_events()
        self.app.selected_id = None
        self.app.reload_groups()
        self.app.clear_form()
        self.app.status_var.set(f"{detail}: {count} removed. Backup: {backup}")
        self.update_counts()
        if reset:
            self.company_combo.configure(values=list(self.app.group_map))
            self.group_name.set(next(iter(self.app.group_map), ""))
            self.update_counts()
        messagebox.showinfo("Roster updated",
                            f"{detail}: {count} people removed.\n\nBackup saved to:\n{backup}",
                            parent=self)

    def delete_selected(self) -> None:
        ids = self.selected_ids()
        if not ids:
            messagebox.showinfo("No selection", "Select one or more people in the main roster first.",
                                parent=self)
            return
        people = [self.app.by_id[i].name for i in ids]
        sample = "\n".join(people[:6]) + (f"\n... and {len(ids)-6} more" if len(ids)>6 else "")
        if not messagebox.askyesno("Delete selected people",
            f"Permanently remove these {len(ids)} people from EVERY event?\n\n{sample}\n\nA backup will be created first.",
            icon="warning", parent=self):
            return
        try:
            removed, backup = self.app.db.delete_people(ids)
        except (OSError, sqlite3.Error, RuntimeError) as exc:
            messagebox.showerror("Delete failed", str(exc), parent=self)
            return
        self.finish(removed, backup, "Selected members deleted")

    def clear_company(self) -> None:
        name = self.group_name.get()
        key = self.app.group_map.get(name)
        if not key:
            messagebox.showinfo("Choose a group", "Choose a company first.", parent=self)
            return
        count = self.app.db.conn.execute(
            "SELECT COUNT(*) FROM cadets WHERE company=?", (key,)
        ).fetchone()[0]
        if not count:
            messagebox.showinfo("Already empty", f"{name} has no members to remove.", parent=self)
            return
        if not messagebox.askyesno("Clear company",
             f"Remove all {count} people in {name} from EVERY event?\n\nOther groups are unaffected. A backup will be created first.",
             icon="warning", parent=self):
            return
        try:
            removed, backup = self.app.db.clear_group(key)
        except (OSError, sqlite3.Error, RuntimeError, ValueError) as exc:
            messagebox.showerror("Clear failed", str(exc), parent=self)
            return
        self.finish(removed, backup, f"{name} cleared")

    def clear_everyone(self) -> None:
        count = self.app.db.conn.execute("SELECT COUNT(*) FROM cadets").fetchone()[0]
        if not count:
            messagebox.showinfo("Already empty", "The roster is already empty.", parent=self)
            return
        if not messagebox.askyesno("Clear the ENTIRE roster",
            f"Remove ALL {count} registered people from EVERY event?\n\nGroup names and event names will stay. A backup will be created first.",
            icon="warning", parent=self):
            return
        try:
            removed, backup = self.app.db.clear_roster()
        except (OSError, sqlite3.Error, RuntimeError) as exc:
            messagebox.showerror("Clear failed", str(exc), parent=self)
            return
        self.finish(removed, backup, "All people cleared")

    def reset_all(self) -> None:
        typed = simpledialog.askstring("Confirm COMPLETE database reset",
            "This deletes all members, attendance, extra events, and custom groups.\n"
            "The default groups and 'Current Event' will be recreated.\n"
            "A backup will be created first.\n\nType RESET to continue:", parent=self)
        if typed != "RESET":
            return
        if not messagebox.askyesno("Last confirmation",
            "Reset ALL roster data and restore the default groups and event?",
            icon="warning", parent=self):
            return
        try:
            removed, backup = self.app.db.reset_database()
        except (OSError, sqlite3.Error, RuntimeError) as exc:
            messagebox.showerror("Reset failed", str(exc), parent=self)
            return
        self.finish(removed, backup, "Database reset to defaults", reset=True)


class FormationApp(tk.Tk):
    def __init__(self, db_path: Path = DB_PATH):
        super().__init__()
        self.db = Registry(db_path)
        self.title("Formation Planner v5.2.5 | Classic + Company Attendance")
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        self.compact_ui = screen_w < 1450 or screen_h < 850
        # Leave room for the OS taskbar and title bar, including display scaling.
        width = min(1550, max(740, screen_w - 85))
        height = min(900, max(485, screen_h - 125))
        self.geometry(f"{width}x{height}")
        self.minsize(min(800, width), min(500, height))
        self.configure(bg="#f2f6f9")
        self.selected_id: int | None = None
        self.roster_sort = "name"
        self.roster_desc = False
        self.event_id = self.db.events()[0][0]
        self.all_people: list[Person] = []
        self.by_id: dict[int, Person] = {}
        self.formations: list[Formation] = []
        self.group_map: dict[str, str] = {}
        self._style()
        self._menu_and_shortcuts()
        self._ui()
        self.load_events()
        self.reload_groups()
        self.refresh()
        self.protocol("WM_DELETE_WINDOW", self.quit_app)

    def open_event_admin(self, initial_tab='Attendance'):
        from admin_ui import AdminDashboard
        AdminDashboard(self, initial_tab)

    def _search_updated(self):
        if not hasattr(self,'search_entry'):
            return
        query = self.search_var.get().casefold().strip()
        matches = [p.name for p in self.all_people if query and query in p.name.casefold()]
        self.search_entry.configure(values=sorted(set(matches),key=str.casefold)[:25])
        self.draw_roster()

    def _choose_suggested_name(self, event=None):
        val = self.search_var.get().casefold().strip()
        matches=[p for p in self.all_people if p.name.casefold()==val]
        if len(matches)==1 and self.tree.exists(str(matches[0].id)):
            self.tree.selection_set(str(matches[0].id))
            self.tree.see(str(matches[0].id))
            self.selected_person()

    def _snapshot_formations(self):
        return sections_for(self.all_people,self.db.groups(),None)

    def finalize_current_formation(self):
        history=self.db.formation_history(self.event_id)
        if history:
            if not messagebox.askyesno('Revise finalized formation',
                'A finalized formation already exists. Create a NEW revision using the latest attendance?\n'
                'The existing formation will remain saved in history.',parent=self):
                return
        elif not messagebox.askyesno('Finalize formation',
                'Save the current generated formation as the finalized version?\n'
                'Future attendance imports will not rearrange this saved version.',parent=self):
            return
        settings={'mode':self.mode_var.get(),'per_row':self.per_row(),
                  'sort_mode':self.sort_var.get(),'tallest_first':self.tallest_first.get()}
        revision=self.db.save_formation_snapshot(self.event_id,self._snapshot_formations(),settings)
        self.draw_formation()
        self.status_var.set(f'Formation revision {revision} saved. Re-finalize to reflect later attendance changes.')

    def _style(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#f2f6f9")
        style.configure("TLabel", background="#f2f6f9", foreground="#15334a", font=("Arial",10))
        style.configure("Heading.TLabel", font=("Arial",19,"bold"), foreground="#123c59")
        style.configure("Section.TLabel", font=("Arial",12,"bold"), foreground="#134a6b")
        style.configure("TButton", padding=(8,5))
        style.configure("Treeview", rowheight=27, font=("Arial",9))
        style.configure("Treeview.Heading", font=("Arial",9,"bold"))

    def _menu_and_shortcuts(self):
        # These are reachable even when the lower editor controls are off screen.
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(label="Import Company Workbook (.xlsx)   Ctrl+I", command=self.import_xlsx)
        file_menu.add_command(label="Import Roster CSV", command=self.import_csv)
        file_menu.add_separator()
        file_menu.add_command(label="Export Roster CSV", command=self.export_roster)
        file_menu.add_command(label="Export This Company CSV", command=self.export_group_csv)
        file_menu.add_command(label="Export Formation Positions CSV", command=self.export_positions)
        file_menu.add_command(label="Printable Formation", command=self.export_html)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit_app)
        menubar.add_cascade(label="File", menu=file_menu)
        manage_menu = tk.Menu(menubar, tearoff=False)
        manage_menu.add_command(label="Manage Roster", command=self.manage_roster)
        manage_menu.add_command(label="Manage Groups", command=self.manage_groups)
        manage_menu.add_command(label="New Event", command=self.new_event)
        manage_menu.add_separator()
        manage_menu.add_command(label="Event Administration", command=self.open_event_admin)
        manage_menu.add_command(label="Roster / Heights Administration", command=lambda: self.open_event_admin('Roster'))
        manage_menu.add_command(label="Finalize / Revise Formation", command=self.finalize_current_formation)
        menubar.add_cascade(label="Manage", menu=manage_menu)
        self.config(menu=menubar)
        self.bind_all("<Control-i>", lambda event: self.import_xlsx())
        self.bind_all("<Control-Shift-I>", lambda event: self.import_csv())
        self.bind_all("<Control-e>", lambda event: self.open_event_admin())

    def show_editor(self):
        """Pop out the original v5.2 add/edit form on small laptop displays."""
        if getattr(self, "editor_window", None) is None:
            return
        popup = self.editor_window
        # Keep the editor inside the visible laptop display area.
        popup_w, popup_h = 470, 425
        x = min(self.winfo_screenwidth() - popup_w - 18,
                self.winfo_rootx() + max(0, (self.winfo_width() - popup_w)//2))
        y = min(self.winfo_screenheight() - popup_h - 30,
                self.winfo_rooty() + max(0, (self.winfo_height() - popup_h)//2))
        popup.geometry(f"+{max(0,x)}+{max(0,y)}")
        popup.deiconify()
        popup.lift()
        popup.focus_force()

    def _ui(self):
        compact = self.compact_ui
        top = ttk.Frame(self, padding=(12,8) if compact else (17,12))
        top.pack(fill="x")
        title_font = ("Arial", 15, "bold") if compact else ("Arial", 19, "bold")
        ttk.Label(top, text="FORMATION PLANNER", font=title_font, foreground="#123c59").pack(side="left")
        ttk.Label(top, text="Event:").pack(side="left", padx=(16 if compact else 27,5))
        self.event_var = tk.StringVar()
        self.event_combo = ttk.Combobox(top, width=17 if compact else 24,
                                        state="readonly", textvariable=self.event_var)
        self.event_combo.pack(side="left")
        self.event_combo.bind("<<ComboboxSelected>>", self.event_changed)
        ttk.Button(top, text="+ New Event", command=self.new_event).pack(side="left", padx=6)
        if not compact:
            ttk.Button(top, text="Manage Groups", command=self.manage_groups).pack(side="left", padx=7)
            ttk.Button(top, text="Manage Roster", command=self.manage_roster).pack(side="left", padx=7)
            ttk.Label(top, text="Independent company blocks • Class and height sorting",
                      foreground="#577489").pack(side="right")

        # Stay visible at every supported screen size. Keyboard/menu fallback above.
        bar = ttk.Frame(self, padding=(12,4) if compact else (17,4))
        bar.pack(fill="x")
        ttk.Button(bar, text="Import Company Workbook (.xlsx)",
                   command=self.import_xlsx).pack(side="left", padx=(0,8))
        ttk.Button(bar, text="Import CSV", command=self.import_csv).pack(side="left", padx=(0,8))
        ttk.Button(bar, text="Manage Roster", command=self.manage_roster).pack(side="left", padx=(0,8))
        ttk.Button(bar, text="Event Admin", command=self.open_event_admin).pack(side="left", padx=(0,8))
        if compact:
            ttk.Button(bar, text="Manage Groups", command=self.manage_groups).pack(side="left", padx=(0,8))

        if compact:
            # Same v5.2 panels, but each gets the whole width on a laptop.
            self.workspace = ttk.Notebook(self)
            self.workspace.pack(fill="both", expand=True, padx=9, pady=(3,4))
            left = ttk.Frame(self.workspace, padding=8)
            right = ttk.Frame(self.workspace, padding=8)
            self.workspace.add(left, text="Company Roster")
            self.workspace.add(right, text="Formation Preview")
        else:
            split = ttk.Panedwindow(self, orient="horizontal")
            split.pack(fill="both", expand=True, padx=14, pady=(0,8))
            left = ttk.Frame(split, padding=11)
            right = ttk.Frame(split, padding=11)
            split.add(left, weight=4)
            split.add(right, weight=6)

        roster_title = ttk.Frame(left)
        roster_title.pack(fill="x")
        ttk.Label(roster_title, text="Company roster editor", style="Section.TLabel").pack(side="left")
        if compact:
            ttk.Button(roster_title, text="Add / Edit Member...",
                       command=self.show_editor).pack(side="right")
        focus = ttk.Frame(left)
        focus.pack(fill="x", pady=(9, 4))
        ttk.Label(focus, text="Edit company:").pack(side="left")
        self.roster_scope_var = tk.StringVar(value=ALL_GROUPS)
        self.roster_scope_combo = ttk.Combobox(focus, state="readonly", width=27,
                                             textvariable=self.roster_scope_var)
        self.roster_scope_combo.pack(side="left", padx=(7, 0), fill="x", expand=True)
        self.roster_scope_combo.bind("<<ComboboxSelected>>", self.roster_scope_changed)
        ttk.Label(left, text="Select multiple with Ctrl/Shift. Click headers to sort; double-click a field to edit.",
                  foreground="#577489").pack(anchor="w")
        search = ttk.Frame(left)
        search.pack(fill="x", pady=(8,6))
        ttk.Label(search, text="Search").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._search_updated())
        self.search_entry = ttk.Combobox(search, textvariable=self.search_var, state="normal")
        self.search_entry.pack(side="left", fill="x", expand=True, padx=7)
        self.search_entry.bind("<<ComboboxSelected>>", self._choose_suggested_name)
        self.search_entry.bind("<Return>", self._choose_suggested_name)
        wrapper = ttk.Frame(left)
        wrapper.pack(fill="both", expand=True)
        cols = ("name", "group", "class", "height", "attend", "role")
        self.tree = ttk.Treeview(wrapper, columns=cols, show="headings", selectmode="extended",
                                 height=4 if compact else 10)
        for key,label,width in [("name","Name",148),("group","Group",96),("class","Class",58),
                                 ("height","Height",58),("attend","Going?",58),("role","Role",77)]:
            self.tree.heading(key, text=label, command=lambda k=key: self.set_roster_sort(k))
            self.tree.column(key, width=width, minwidth=48, stretch=(key=="name"))
        self.tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(wrapper, orient="vertical", command=self.tree.yview)
        sb.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<<TreeviewSelect>>", self.selected_person)
        self.tree.bind("<Double-1>", self.quick_edit)

        self.editor_window = None
        if compact:
            self.editor_window = tk.Toplevel(self)
            self.editor_window.title("Add / Edit Member | Formation Planner")
            self.editor_window.geometry("470x425")
            self.editor_window.minsize(410, 365)
            self.editor_window.transient(self)
            self.editor_window.protocol("WM_DELETE_WINDOW", self.editor_window.withdraw)
            editor_parent = self.editor_window
        else:
            editor_parent = left
        editor = ttk.LabelFrame(editor_parent, text="Add / edit member", padding=9)
        editor.pack(fill="x", padx=8 if compact else 0, pady=(10,7))
        if compact:
            self.editor_window.withdraw()
        f = ttk.Frame(editor)
        f.pack(fill="x")
        self.name_var = tk.StringVar()
        self.group_var = tk.StringVar()
        self.ft_var = tk.StringVar(value="")
        self.in_var = tk.StringVar(value="")
        self.role_var = tk.StringVar(value="Member")
        self.class_var = tk.StringVar(value="")
        self.attending_var = tk.BooleanVar(value=True)
        ttk.Label(f, text="Full name").grid(row=0,column=0,sticky="w",pady=4)
        ttk.Entry(f, textvariable=self.name_var).grid(row=0,column=1,columnspan=4,sticky="ew",padx=5)
        ttk.Label(f, text="Group").grid(row=1,column=0,sticky="w",pady=4)
        self.group_combo = ttk.Combobox(f, state="readonly", textvariable=self.group_var)
        self.group_combo.grid(row=1,column=1,columnspan=4,sticky="ew",padx=5)
        ttk.Label(f, text="Height (optional)").grid(row=2,column=0,sticky="w",pady=4)
        ttk.Spinbox(f, from_=0, to=9, width=5, textvariable=self.ft_var).grid(row=2,column=1,sticky="w",padx=5)
        ttk.Label(f, text="ft").grid(row=2,column=2,sticky="w")
        ttk.Spinbox(f, from_=0, to=11, width=5, textvariable=self.in_var).grid(row=2,column=3,sticky="w",padx=5)
        ttk.Label(f, text="in").grid(row=2,column=4,sticky="w")
        ttk.Label(f, text="Class").grid(row=3,column=0,sticky="w",pady=4)
        ttk.Combobox(f, textvariable=self.class_var, values=CLASS_CHOICES, width=22).grid(
            row=3,column=1,columnspan=4,sticky="ew",padx=5)
        ttk.Label(f, text="Role").grid(row=4,column=0,sticky="w",pady=4)
        ttk.Combobox(f, textvariable=self.role_var, values=ROLE_CHOICES, width=22).grid(
            row=4,column=1,columnspan=4,sticky="ew",padx=5)
        ttk.Checkbutton(f, text="Attending this event", variable=self.attending_var).grid(
            row=5,column=0,columnspan=5,sticky="w",pady=(6,0))
        f.columnconfigure(1,weight=1)
        buttonline = ttk.Frame(editor)
        buttonline.pack(fill="x",pady=(9,0))
        ttk.Button(buttonline, text="Save", command=self.save_person).pack(side="left",padx=(0,6))
        ttk.Button(buttonline, text="New / Clear", command=self.clear_form).pack(side="left",padx=6)
        ttk.Button(buttonline, text="Delete", command=self.delete_person).pack(side="left",padx=6)
        bottom = ttk.Frame(left)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Toggle Attendance", command=self.toggle_attendance).pack(side="left",padx=(0,4))
        ttk.Button(bottom, text="Import CSV", command=self.import_csv).pack(side="left",padx=4)
        ttk.Button(bottom, text="Export Roster", command=self.export_roster).pack(side="left",padx=4)
        extras = ttk.Frame(left)
        extras.pack(fill="x", pady=(7,0))
        ttk.Button(extras, text="Export This Company CSV", command=self.export_group_csv).pack(side="left",padx=(0,6))
        if compact:
            # Reserve room for these important editing actions *above* the table.
            # Otherwise Treeview's requested height can push them below the screen.
            bottom.pack_configure(before=wrapper)
            extras.pack_configure(before=wrapper)
        else:
            ttk.Button(extras, text="Import Company Workbook (.xlsx)", command=self.import_xlsx).pack(side="left")

        header = ttk.Frame(right)
        header.pack(fill="x")
        ttk.Label(header, text="Formation preview", style="Section.TLabel").pack(side="left")
        ttk.Label(header, text="Group:").pack(side="left",padx=(18,5))
        self.view_var = tk.StringVar(value=OVERVIEW)
        self.view_combo = ttk.Combobox(header, state="readonly", width=27, textvariable=self.view_var)
        self.view_combo.pack(side="left")
        self.view_combo.bind("<<ComboboxSelected>>",lambda *_: self.draw_formation())
        controls = ttk.Frame(right)
        controls.pack(fill="x", pady=(9,7))
        ttk.Label(controls, text="Style:").pack(side="left")
        self.mode_var = tk.StringVar(value="Ranks")
        self.mode_combo = ttk.Combobox(controls, state="readonly", width=16, values=MODES, textvariable=self.mode_var)
        self.mode_combo.pack(side="left",padx=5)
        self.mode_combo.bind("<<ComboboxSelected>>",lambda *_: self.draw_formation())
        ttk.Label(controls, text="Sort by:").pack(side="left",padx=(12,0))
        self.sort_var = tk.StringVar(value="Height only")
        self.sort_combo = ttk.Combobox(controls, state="readonly", values=SORT_MODES,
                                      width=18, textvariable=self.sort_var)
        self.sort_combo.pack(side="left",padx=5)
        self.sort_combo.bind("<<ComboboxSelected>>", lambda *_: self.draw_formation())
        ttk.Label(controls, text="Per rank:").pack(side="left",padx=(12,0))
        self.per_row_var = tk.StringVar(value="8")
        self.per_row_spin = ttk.Spinbox(controls, from_=1, to=32, width=5, textvariable=self.per_row_var)
        self.per_row_spin.pack(side="left",padx=5)
        self.per_row_spin.bind("<Return>",lambda *_: self.draw_formation())
        self.per_row_spin.bind("<FocusOut>",lambda *_: self.draw_formation())
        self.tallest_first = tk.BooleanVar(value=True)
        ttk.Checkbutton(controls, text="Tallest first", variable=self.tallest_first,
                        command=self.draw_formation).pack(side="left",padx=(14,0))
        exports = ttk.Frame(right)
        exports.pack(fill="x",pady=(0,6))
        ttk.Button(exports, text="Refresh", command=self.draw_formation).pack(side="left",padx=(0,7))
        ttk.Button(exports, text="Export Positions CSV", command=self.export_positions).pack(side="left",padx=7)
        ttk.Button(exports, text="Printable Formation", command=self.export_html).pack(side="left",padx=7)
        ttk.Label(exports, text="Each group fills right to left", foreground="#52768e").pack(side="right")
        box = ttk.Frame(right)
        box.pack(fill="both",expand=True)
        self.canvas = tk.Canvas(box, bg="white", highlightthickness=1, highlightbackground="#bbccd6")
        vs = ttk.Scrollbar(box, orient="vertical", command=self.canvas.yview)
        hs = ttk.Scrollbar(box, orient="horizontal",command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        self.canvas.grid(row=0,column=0,sticky="nsew")
        vs.grid(row=0,column=1,sticky="ns")
        hs.grid(row=1,column=0,sticky="ew")
        box.rowconfigure(0,weight=1)
        box.columnconfigure(0,weight=1)
        self.canvas.bind("<MouseWheel>",lambda ev: self.canvas.yview_scroll(-3 if ev.delta>0 else 3,"units"))
        self.canvas.bind("<Button-4>",lambda _: self.canvas.yview_scroll(-3,"units"))
        self.canvas.bind("<Button-5>",lambda _: self.canvas.yview_scroll(3,"units"))
        ttk.Button(exports, text="Finalize / Revise", command=self.finalize_current_formation).pack(side="left",padx=(6,0))
        self.info_var = tk.StringVar()
        ttk.Label(right,textvariable=self.info_var,wraplength=800).pack(anchor="w",pady=(7,0))
        self.status_var = tk.StringVar(value="Ready — import Excel from the toolbar or File menu (Ctrl+I)")
        ttk.Label(self,textvariable=self.status_var,padding=(12,0,12,5) if compact else (17,0,17,12),
                  foreground="#527085").pack(anchor="w")

    def load_events(self):
        self.event_map = {name: key for key,name in self.db.events()}
        self.event_combo.configure(values=list(self.event_map))
        self.event_var.set(next(n for n,i in self.event_map.items() if i == self.event_id))

    def reload_groups(self):
        groups = self.db.groups()
        old_key = self.group_map.get(self.group_var.get())
        old_view = self.view_var.get()
        old_view_key = self.group_map.get(old_view)
        self.group_map = {g.name: g.key for g in groups}
        self.group_combo.configure(values=list(self.group_map))
        prior_scope = self.roster_scope_var.get()
        self.roster_scope_combo.configure(values=[ALL_GROUPS]+list(self.group_map))
        self.roster_scope_var.set(prior_scope if prior_scope in self.group_map or prior_scope == ALL_GROUPS
                                  else ALL_GROUPS)
        if old_key:
            self.group_var.set(next((g.name for g in groups if g.key == old_key), groups[0].name if groups else ""))
        elif self.group_var.get() not in self.group_map:
            self.group_var.set(groups[0].name if groups else "")
        self.view_combo.configure(values=[OVERVIEW]+[name for name,key in self.group_map.items() if key not in {'PIPE','FOOT','SUPPORT'}])
        if old_view == OVERVIEW:
            self.view_var.set(OVERVIEW)
        elif old_view_key:
            self.view_var.set(next((g.name for g in groups if g.key == old_view_key), OVERVIEW))
        elif old_view not in self.group_map:
            self.view_var.set(OVERVIEW)
        self.refresh()

    def refresh(self, keep_selection: int | None = None):
        self.all_people = self.db.roster(self.event_id)
        self.by_id = {p.id:p for p in self.all_people}
        self.draw_roster(keep_selection)
        self.draw_formation()

    def draw_roster(self, keep_selection: int | None = None):
        if not hasattr(self,"tree"):
            return
        keys = {g.key:g.name for g in self.db.groups()}
        query = self.search_var.get().casefold().strip()
        selected = keep_selection or self.selected_id
        scope = self.group_map.get(self.roster_scope_var.get())
        self.tree.delete(*self.tree.get_children())
        def roster_sort_key(p: Person):
            sort = self.roster_sort
            if sort == "group":
                return (keys.get(p.group,p.group).casefold(),p.name.casefold())
            if sort == "class":
                return (*class_sort_key(p.cadet_class),p.name.casefold())
            if sort == "height":
                return (p.height_inches,p.name.casefold())
            if sort == "attend":
                return (p.attending,p.name.casefold())
            if sort == "role":
                return (p.role.casefold(),p.name.casefold())
            return (p.name.casefold(),p.id)
        for p in sorted(self.all_people, key=roster_sort_key, reverse=self.roster_desc):
            if scope is not None and p.group != scope:
                continue
            group = keys.get(p.group,p.group)
            if query and query not in f"{p.name} {group} {p.cadet_class} {p.role}".casefold():
                continue
            self.tree.insert("", "end",iid=str(p.id),values=(p.name,group,p.cadet_class,show_height(p.height_inches),
                            "Yes" if p.attending else "No",p.role))
        if selected is not None and self.tree.exists(str(selected)):
            self.tree.selection_set(str(selected))
            self.tree.see(str(selected))

    def set_roster_sort(self, key: str):
        if self.roster_sort == key:
            self.roster_desc = not self.roster_desc
        else:
            self.roster_sort = key
            self.roster_desc = key == "height"
        self.draw_roster()

    def selected_person(self, *_):
        selected = self.tree.selection()
        if not selected or len(selected) != 1:
            self.selected_id = None
            if len(selected) > 1:
                self.name_var.set("")
                self.status_var.set(f"{len(selected)} members selected. Choose Manage Roster to delete them.")
            return
        p = self.by_id.get(int(selected[0]))
        if p is None:
            return
        self.selected_id = p.id
        self.name_var.set(p.name)
        self.group_var.set(next((g.name for g in self.db.groups() if g.key == p.group),""))
        feet,inch = divmod(p.height_inches,12)
        self.ft_var.set(str(feet) if p.height_inches else "")
        self.in_var.set(str(inch) if p.height_inches else "")
        self.attending_var.set(p.attending)
        self.role_var.set(p.role)
        self.class_var.set(p.cadet_class)

    def clear_form(self):
        self.selected_id = None
        self.tree.selection_remove(self.tree.selection())
        self.name_var.set("")
        groups = self.db.groups()
        self.group_var.set(self.roster_scope_var.get() if self.roster_scope_var.get() in self.group_map
                           else (groups[0].name if groups else ""))
        self.ft_var.set("")
        self.in_var.set("")
        self.role_var.set("Member")
        self.class_var.set("")
        self.attending_var.set(True)

    def save_person(self):
        try:
            group = self.db.resolve_group(self.group_var.get())
            ft, inch = self.ft_var.get().strip(), self.in_var.get().strip()
            height = height_from_parts(int(ft or "0"), int(inch or "0")) if ft or inch else 0
            p_id = self.db.save_person(self.selected_id,self.name_var.get(),group,height,
                                       self.role_var.get(),self.attending_var.get(),self.event_id,
                                       self.class_var.get())
        except (ValueError,sqlite3.IntegrityError) as exc:
            messagebox.showerror("Invalid member",str(exc),parent=self)
            return
        self.selected_id = p_id
        self.refresh(p_id)
        self.status_var.set(f"Saved {clean(self.name_var.get())}.")

    def delete_person(self):
        if self.selected_id is None:
            messagebox.showinfo("Select member", "Select someone in the roster first.",parent=self)
            return
        p = self.by_id[self.selected_id]
        if messagebox.askyesno("Delete member",
                               f"Delete {p.name} from every event? A backup will be created first.",
                               parent=self):
            try:
                _, backup = self.db.delete_person(p.id)
            except (OSError, sqlite3.Error, RuntimeError) as exc:
                messagebox.showerror("Delete failed", str(exc), parent=self)
                return
            self.clear_form()
            self.refresh()
            self.status_var.set(f"Deleted {p.name}. Backup: {backup}")

    def toggle_attendance(self):
        if self.selected_id is None:
            messagebox.showinfo("Select member","Select someone first.",parent=self)
            return
        p = self.by_id[self.selected_id]
        self.db.set_attendance(self.event_id,p.id,not p.attending)
        self.refresh(p.id)
        self.attending_var.set(not p.attending)
        self.status_var.set(f"{p.name}: {'attending' if not p.attending else 'absent'}")

    def event_changed(self,*_):
        self.event_id = self.event_map[self.event_var.get()]
        self.clear_form()
        self.refresh()

    def new_event(self):
        name = simpledialog.askstring("New Event","Event name:",parent=self)
        if name is None:
            return
        try:
            self.event_id = self.db.new_event(name)
        except (ValueError,sqlite3.IntegrityError) as exc:
            messagebox.showerror("Could not add event",str(exc),parent=self)
            return
        self.load_events()
        self.clear_form()
        self.refresh()
        self.status_var.set(f"Created event: {clean(name)}. Everyone defaults to attending.")

    def manage_groups(self):
        GroupManager(self)

    def manage_roster(self):
        RosterManager(self)

    def per_row(self) -> int:
        try:
            count = int(self.per_row_var.get())
            if not 1 <= count <= 32:
                raise ValueError
            return count
        except ValueError:
            self.per_row_var.set("8")
            return 8

    def current_formations(self):
        selected = None if self.view_var.get() == OVERVIEW else self.group_map.get(self.view_var.get())
        frozen=self.db.load_formation_snapshot(self.event_id)
        if frozen is not None:
            revision,payload=frozen
            # Display immutable copies of the roster snapshot; new imports do
            # not move cadets around in the finalized view.
            sections=[]
            for block in payload['sections']:
                if selected is not None and block['key']!=selected:continue
                sections.append(Formation(Group(block['key'],block['name']),
                                          [Person(**p) for p in block['members']],
                                          [Person(**p) for p in block['leaders']]))
            return sections
        return sections_for(self.all_people,self.db.groups(),selected)

    def draw_formation(self):
        if not hasattr(self,"canvas"):
            return
        self.canvas.delete("all")
        self.formations = self.current_formations()
        frozen=self.db.load_formation_snapshot(self.event_id)
        if frozen is not None:
            settings=frozen[1].get('settings',{})
            mode=settings.get('mode',self.mode_var.get())
            n=int(settings.get('per_row',self.per_row()))
            sort_mode=settings.get('sort_mode',self.sort_var.get())
            tallest=bool(settings.get('tallest_first',self.tallest_first.get()))
        else:
            mode=self.mode_var.get()
            n=self.per_row()
            sort_mode=self.sort_var.get()
            tallest=self.tallest_first.get()
        max_w = 0
        max_h = 130
        x = 36
        y0 = 155
        self.canvas.create_text(40,35,text="↑  FRONT / FACING  ↑",anchor="w",fill="#17688d",
                                font=("Arial",16,"bold"))
        detail = f"Sort: {sort_mode}  |  Within each group, position 1 is at the front right."
        if sort_mode != "Class only":
            detail += "  Tallest first." if tallest else "  Shortest first."
        self.canvas.create_text(40,68,text=detail,anchor="w",fill="#60788b",font=("Arial",10))
        self.canvas.create_text(40,92,text=f"Each group gets its own {n}-wide block. Front ranks align side by side.",
                                anchor="w",fill="#60788b",font=("Arial",10))
        if not self.formations:
            self.canvas.create_text(50,156,text="No attending members to display. Add a person or select a group.",
                                    anchor="w",fill="#6e8293")
        for group_index,formation in enumerate(self.formations):
            rows = make_rows(formation.members,mode,n,tallest,sort_mode)
            cols = 1 if mode == "Single file" else (max(1,len(formation.members)) if mode=="Line abreast" else n)
            tile_w = 164 if mode == "Single file" else (95 if mode == "Ranks" else 115)
            space = 6 if mode == "Ranks" else 10
            width = max(210,cols * (tile_w + space) + 18)
            # Identical top edge for every company, regardless of leadership.
            people_y = y0 + 33
            row_h = 80 if mode == "Ranks" else (75 if mode == "Single file" else 93)
            panel_h = 115 + max(1,len(rows))*row_h + 16
            fill = COLORS[group_index % len(COLORS)]
            self.canvas.create_rectangle(x-10,y0-46,x+width,y0+panel_h,fill="#fbfdff",outline="#d4e1e9",width=1)
            self.canvas.create_rectangle(x-10,y0-46,x+width,y0-9,fill="#e9f1f7",outline="")
            self.canvas.create_text(x+7,y0-27,text=f"{formation.group.name}   ·   {len(formation.members)} in formation",
                                    anchor="w",fill="#16405c",font=("Arial",11,"bold"))
            if formation.leaders:
                lead_text = "  |  ".join(f"{p.role}: {p.name}" for p in formation.leaders)
                self.canvas.create_text(x+4,y0+8,text=lead_text[:85],anchor="w",fill="#567083",
                                        font=("Arial",9))
            if mode == "Single file" and len(rows)>1:
                cx = x + tile_w/2+14
                self.canvas.create_line(cx,people_y+24,cx,people_y+(len(rows)-1)*row_h+24,
                                        fill="#acbecb",dash=(6,6),width=3)
            if not rows:
                self.canvas.create_text(x+8,people_y+34,text="No attending members in ranks",anchor="w",
                                        fill="#8295a3",font=("Arial",10,"italic"))
            ordered = ordered_members(formation.members,tallest,sort_mode)
            number = {p.id:i+1 for i,p in enumerate(ordered)}
            for rownum,row in enumerate(rows):
                if mode=="Ranks":
                    self.canvas.create_text(x,people_y+rownum*row_h-7,text=f"ROW {rownum+1}" + ("  /  FRONT" if rownum == 0 else ""),anchor="w",
                                            fill="#46738f",font=("Arial",8,"bold"))
                for colnum,person in enumerate(row):
                    if person is None:
                        continue
                    x1 = x+colnum*(tile_w+space)+4
                    yy = people_y+rownum*row_h+4
                    if mode == "Ranks":
                        # Compact numbered cards let each company remain visibly 8 wide.
                        self.canvas.create_rectangle(x1,yy,x1+tile_w,yy+61,fill="white",outline="#c6d9e5")
                        self.canvas.create_rectangle(x1,yy,x1+tile_w,yy+5,fill=fill,outline="")
                        self.canvas.create_oval(x1+4,yy+10,x1+29,yy+35,fill=fill,outline="")
                        self.canvas.create_text(x1+16.5,yy+22,text=str(number[person.id]),fill="white",
                                                font=("Arial",8,"bold"))
                        name = person.name if len(person.name) <= 12 else (
                            person.name[0] + ". " + person.name.split()[-1])
                        self.canvas.create_text(x1+33,yy+22,text=name[:11] + ("…" if len(name)>11 else ""),
                                                anchor="w",fill="#1d3f57",font=("Arial",8,"bold"))
                        self.canvas.create_text(x1+tile_w/2,yy+47,text=f"{person.cadet_class or '—'} | {show_height(person.height_inches)}",
                                                fill="#698096",font=("Arial",9))
                    else:
                        self.canvas.create_rectangle(x1,yy,x1+tile_w,yy+60,fill="white",outline="#c6d9e5")
                        self.canvas.create_rectangle(x1,yy,x1+5,yy+60,fill=fill,outline="")
                        self.canvas.create_oval(x1+11,yy+13,x1+40,yy+42,fill=fill,outline="")
                        self.canvas.create_text(x1+25,yy+27,text=str(number[person.id]),fill="white",
                                                font=("Arial",9,"bold"))
                        self.canvas.create_text(x1+48,yy+19,text=person.name if len(person.name)<20 else person.name[:18]+"…",
                                                anchor="w",fill="#1d3f57",font=("Arial",9,"bold"))
                        self.canvas.create_text(x1+48,yy+42,text=f"{person.cadet_class or '—'} | {show_height(person.height_inches)}",anchor="w",
                                                fill="#698096",font=("Arial",9))
            max_h = max(max_h,y0+panel_h+24)
            x += width + 20
            max_w = max(max_w,x+16)
        self.canvas.configure(scrollregion=(0,0,max(730,max_w),max(360,max_h)))
        self.canvas.xview_moveto(0)
        registered = len(self.all_people)
        missing_heights = sum(p.height_inches <= 0 for p in self.all_people)
        present = sum(p.attending for p in self.all_people)
        in_formation = sum(len(f.members) for f in self.formations)
        self.info_var.set(f"{registered} registered  •  {missing_heights} heights not entered  •  "
                          f"{present} attending this event  •  "
                          f"{in_formation} in displayed formations  •  {mode}  •  {sort_mode}  •  "
                          "Leaders listed separately")

    def roster_scope_changed(self, *_):
        self.selected_id = None
        self.clear_form()
        self.draw_roster()
        scope = self.roster_scope_var.get()
        self.status_var.set(f"Editing: {scope}")

    def quick_edit(self, event):
        """Double-click attendance to toggle, or edit common fields directly."""
        row_id = self.tree.identify_row(event.y)
        col_id = self.tree.identify_column(event.x)
        if not row_id or not col_id:
            return
        person = self.by_id.get(int(row_id))
        if person is None:
            return
        col = int(col_id[1:])
        if col == 5:  # Attending
            self.db.set_attendance(self.event_id,person.id,not person.attending)
            self.refresh(person.id)
            return
        if col == 3:  # Class
            value = simpledialog.askstring("Edit class", "Class (1/c, 2/c, 3/c, 4/c, or year):",
                                            initialvalue=person.cadet_class,parent=self)
        elif col == 4:  # Height
            value = simpledialog.askstring("Edit height", "Enter height as feet'inches (example: 5'11):",
                                            initialvalue=(f"{person.height_inches//12}'{person.height_inches%12}"
                                                          if person.height_inches else ""),parent=self)
        elif col == 1:  # Name
            value = simpledialog.askstring("Edit name", "Name:",initialvalue=person.name,parent=self)
        else:
            # Role/company can be changed using the edit panel.
            self.selected_person()
            return
        if value is None:
            return
        try:
            name, height, cls = person.name, person.height_inches, person.cadet_class
            if col == 1:
                name = value
            elif col == 3:
                cls = value
            else:
                if not value.strip():
                    height = 0  # Double-click height and clear to mark unknown.
                else:
                    match = re.fullmatch(r"\s*(\d+)\s*['’]\s*(\d{1,2})\s*(?:[\"])?\s*", value)
                    if not match:
                        raise ValueError("Use feet'inches, e.g. 5'11, or leave blank")
                    height = height_from_parts(int(match.group(1)),int(match.group(2)))
            self.db.save_person(person.id,name,person.group,height,person.role,
                                person.attending,self.event_id,cls)
        except (ValueError,sqlite3.Error) as exc:
            messagebox.showerror("Could not edit member",str(exc),parent=self)
            return
        self.refresh(person.id)
        self.selected_person()

    def export_group_csv(self):
        scope = self.group_map.get(self.roster_scope_var.get())
        if scope is None:
            messagebox.showinfo("Select a company", "Choose one company in Edit company first.",parent=self)
            return
        name = self.roster_scope_var.get()
        safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", name).strip("_")
        filename = filedialog.asksaveasfilename(defaultextension=".csv",initialfile=f"{safe}_roster.csv",
                    filetypes=[("CSV files","*.csv")])
        if filename:
            export_company_roster(Path(filename),[p for p in self.all_people if p.group==scope])
            self.status_var.set(f"Exported {name} roster: {filename}")

    def import_xlsx(self):
        filename = filedialog.askopenfilename(title="Import workbook (one company per sheet)",
                                               filetypes=[("Excel workbook","*.xlsx")], parent=self)
        if not filename:
            return
        try:
            records = read_company_workbook(Path(filename))
            added,updated = self.db.import_rows(records,self.event_id)
        except (OSError,ValueError,KeyError,IndexError,ET.ParseError,zipfile.BadZipFile,sqlite3.Error) as exc:
            messagebox.showerror("Excel import failed",str(exc),parent=self)
            return
        self.reload_groups()
        self.clear_form()
        missing = sum(p.height_inches == 0 for p in self.all_people)
        self.status_var.set(f"Imported workbook: {added} added, {updated} updated; {missing} heights missing.")
        messagebox.showinfo("Workbook imported",
            f"Added {added} people and updated {updated}.\n"
            f"{missing} people have no height recorded. Height-based positions are provisional until filled in.",
            parent=self)

    def import_csv(self):
        filename = filedialog.askopenfilename(title="Import roster",filetypes=[("CSV files","*.csv")], parent=self)
        if not filename:
            return
        try:
            with open(filename,newline="",encoding="utf-8-sig") as fh:
                reader = csv.DictReader(fh)
                if not reader.fieldnames:
                    raise ValueError("CSV needs a header row.")
                rows = list(reader)
            default = self.group_map.get(self.roster_scope_var.get())
            added,updated = self.db.import_rows(rows,self.event_id,default_group=default)
        except (OSError,ValueError,csv.Error) as exc:
            messagebox.showerror("Import failed",str(exc),parent=self)
            return
        self.reload_groups()
        self.clear_form()
        missing = sum(p.height_inches == 0 for p in self.all_people)
        self.status_var.set(f"Imported CSV: {added} added, {updated} updated; {missing} heights missing.")
        messagebox.showinfo("Import complete",
            f"Added {added} people and updated {updated}.\n"
            f"{missing} people have no height recorded. Height-based positions are provisional until filled in.",
            parent=self)

    def export_roster(self):
        filename = filedialog.asksaveasfilename(defaultextension=".csv",initialfile="roster.csv",
                    filetypes=[("CSV files","*.csv")])
        if filename:
            export_roster(Path(filename),self.all_people,{g.key:g.name for g in self.db.groups()})
            self.status_var.set(f"Roster exported: {filename}")

    def export_settings(self):
        frozen=self.db.load_formation_snapshot(self.event_id)
        return frozen[1]['settings'] if frozen else {'mode':self.mode_var.get(),
             'per_row':self.per_row(),'tallest_first':self.tallest_first.get(),
             'sort_mode':self.sort_var.get()}

    def export_positions(self):
        filename = filedialog.asksaveasfilename(defaultextension=".csv",initialfile="formation_positions.csv",
                    filetypes=[("CSV files","*.csv")])
        if filename:
            cfg=self.export_settings()
            export_positions(Path(filename),self.formations,self.event_var.get(),cfg['mode'],
                             cfg['per_row'],cfg['tallest_first'],cfg['sort_mode'])
            self.status_var.set(f"Positions exported: {filename}")

    def export_html(self):
        filename = filedialog.asksaveasfilename(defaultextension=".html",initialfile="formation_printable.html",
                    filetypes=[("HTML files","*.html")])
        if filename:
            cfg=self.export_settings()
            export_printable(Path(filename),self.formations,self.event_var.get(),cfg['mode'],
                             cfg['per_row'],cfg['tallest_first'],cfg['sort_mode'])
            self.status_var.set(f"Printable formation saved: {filename}")
            webbrowser.open(Path(filename).resolve().as_uri())

    def quit_app(self):
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    FormationApp().mainloop()
