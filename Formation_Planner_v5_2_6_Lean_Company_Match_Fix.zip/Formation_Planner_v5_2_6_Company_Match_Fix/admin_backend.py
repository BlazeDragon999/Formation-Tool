"""Formation Planner administrative data layer (v5.2.6).

Uses only the Python standard library.  Never stores medical details, only a
cadet-selected high-level attendance classification.  SQLite is authoritative;
XLSX files are portable input/output documents, never the primary database.
"""
from __future__ import annotations

import csv
import hashlib
import json
import posixpath
import re
import zipfile
from collections import Counter
from datetime import datetime, date, time
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape, quoteattr

STATUS_CHOICES = (
    "Attending", "Excused", "Medical Excusal", "Pipe Band", "Football",
    "Game Support", "Other"
)
MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships'

def now():
    return datetime.now().isoformat(timespec='seconds')

def last_name_first(name):
    name = ' '.join(str(name).split())
    if ',' in name:
        return name
    parts = name.split()
    return f'{parts[-1]}, {" ".join(parts[:-1])}' if len(parts) > 1 else name

def class_order(value):
    m = re.match(r'([1-4])\s*/?c', str(value).strip(), re.I)
    if m: return int(m.group(1))
    m = re.match(r'20(\d\d)$', str(value).strip())
    if m: return int(m.group(1))-26  # 2027 -> 1/c
    return 9

def norm_name(value):
    name = str(value or '').strip().casefold()
    name = re.sub(r'\s+[1-4]\s*/?c\s*$', '', name)
    if ',' in name:
        last, first = name.split(',', 1)
        name = first.strip() + ' ' + last.strip()
    return re.sub(r'[^a-z0-9]', '', name)

def _xl_col(n):
    s = ''
    while n:
        n, d = divmod(n-1,26)
        s = chr(65+d)+s
    return s

def _cell(ref, value, style=0):
    if value is None or value == '':
        return f'<c r={quoteattr(ref)} s="{style}"/>' if style else ''
    a = f' r={quoteattr(ref)} s="{style}"'
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return f'<c{a}><v>{value}</v></c>'
    return f'<c{a} t="inlineStr"><is><t xml:space="preserve">{escape(str(value))}</t></is></c>'

def write_xlsx(path: Path, sheets: list[dict]):
    """Write small, Excel-compatible XLSX files with dropdown validation.

    Sheet config: name, rows, header_row (1-based), dropdown=(col, first,last),
    hidden_cols, widths, sheet_protection=False, hidden=False, class_band=True.
    Workbook is intentionally dependency-free for the user's Windows PC.
    """
    path = Path(path)
    content_types = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
                     '<Default Extension="xml" ContentType="application/xml"/>',
                     '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
                     '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    sheet_meta = []
    rels = []
    sheet_xmls = []
    for i, sheet in enumerate(sheets, 1):
        name = sheet['name']
        content_types.append(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
        sheet_meta.append(f'<sheet name={quoteattr(name)} sheetId="{i}" r:id="rId{i}"'+(' state="hidden"' if sheet.get('hidden') else '')+'/>')
        rels.append(f'<Relationship Id="rId{i}" Type="{REL}/worksheet" Target="worksheets/sheet{i}.xml"/>')
        rows_xml = []
        header = sheet.get('header_row', 1)
        for ridx, row in enumerate(sheet['rows'], 1):
            cells = []
            is_header = ridx == header
            is_title = ridx == 1 and header != 1
            is_band = bool(sheet.get('class_band')) and not is_header and ridx > header and row and row[0] in ('1/c','2/c','3/c','4/c') and False
            for j, val in enumerate(row, 1):
                editable = sheet.get('editable_cols', [sheet.get('dropdown_col'), sheet.get('dropdown_col',0)+1])
                style = 1 if is_header else 2 if is_title else 3 if j in editable and ridx > header else 0
                if sheet.get('class_band') and ridx > header and ridx % 2 == 0 and style == 0:
                    style = 4
                cells.append(_cell(f'{_xl_col(j)}{ridx}', val, style))
            rows_xml.append(f'<row r="{ridx}"'+(' ht="29" customHeight="1"' if is_title else '')+'>'+''.join(cells)+'</row>')
        cols = []
        for j, width in enumerate(sheet.get('widths', []), 1):
            hidden = ' hidden="1"' if j in sheet.get('hidden_cols', []) else ''
            cols.append(f'<col min="{j}" max="{j}" width="{width}" customWidth="1"{hidden}/>')
        maxcol = max((len(row) for row in sheet['rows']), default=1)
        xml = [f'<worksheet xmlns="{MAIN}">',f'<dimension ref="A1:{_xl_col(maxcol)}{len(sheet["rows"])}"/>',
               '<sheetViews><sheetView workbookViewId="0" showGridLines="0">']
        if header > 1 and not sheet.get('hidden'):
            xml.append(f'<pane ySplit="{header}" topLeftCell="A{header+1}" activePane="bottomLeft" state="frozen"/>')
        xml.append('</sheetView></sheetViews>')
        if cols: xml.append('<cols>'+''.join(cols)+'</cols>')
        xml.append('<sheetData>'+''.join(rows_xml)+'</sheetData>')
        if sheet.get('protected'):
            xml.append('<sheetProtection sheet="1" objects="1" scenarios="1" formatCells="1" insertRows="1" deleteRows="1" sort="0" autoFilter="0"/>')
        if sheet.get('filter'):
            xml.append(f'<autoFilter ref="A{header}:{_xl_col(maxcol)}{len(sheet["rows"])}"/>')
        col = sheet.get('dropdown_col')
        if col:
            start = header+1
            end = len(sheet['rows'])
            choices = ','.join(sheet.get('choices', STATUS_CHOICES))
            # Excel inline validation list is limited to 255 chars; ours is ~92.
            xml.append('<dataValidations count="1">'+
                       f'<dataValidation type="list" errorStyle="stop" allowBlank="0" showErrorMessage="1" '+
                       f'errorTitle="Choose a listed status" error="Select an option from the dropdown." '+
                       f'sqref="{_xl_col(col)}{start}:{_xl_col(col)}{end}"><formula1>"{escape(choices)}"</formula1></dataValidation>'+ 
                       '</dataValidations>')
        xml.append('</worksheet>')
        sheet_xmls.append(''.join(xml))
    styles = (f'<styleSheet xmlns="{MAIN}"><fonts count="3">'
              '<font><sz val="11"/><name val="Aptos"/></font>'
              '<font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font>'
              '<font><b/><color rgb="FF133853"/><sz val="15"/><name val="Aptos"/></font>'
              '</fonts><fills count="5"><fill><patternFill patternType="none"/></fill>'
              '<fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FF153B55"/></patternFill></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFE5F5EB"/></patternFill></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFF3F7FA"/></patternFill></fill>'
              '</fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="5">'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
              '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
              '<xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1" applyProtection="1"><protection locked="0"/></xf>'
              '<xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyFill="1"/>'
              '</cellXfs></styleSheet>')
    workbook = f'<workbook xmlns="{MAIN}" xmlns:r="{REL}"><sheets>'+''.join(sheet_meta)+'</sheets></workbook>'
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', f'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'+''.join(content_types)+'</Types>')
        z.writestr('_rels/.rels', f'<Relationships xmlns="{PKG_REL}"><Relationship Id="rId1" Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml',workbook)
        z.writestr('xl/_rels/workbook.xml.rels',f'<Relationships xmlns="{PKG_REL}">'+''.join(rels)+f'<Relationship Id="style" Type="{REL}/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml',styles)
        for i, raw in enumerate(sheet_xmls, 1):
            z.writestr(f'xl/worksheets/sheet{i}.xml',raw)

def read_xlsx(path):
    """Read values and physical row numbers, supporting shared/inline Excel strings."""
    result = {}
    with zipfile.ZipFile(path) as z:
        total = sum(item.file_size for item in z.infolist())
        if total > 90_000_000:
            raise ValueError('Workbook is unusually large; use a smaller attendance file.')
        q = lambda tag: '{'+MAIN+'}'+tag
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            strs = ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared = [''.join(t.text or '' for t in si.iter(q('t'))) for si in strs.findall(q('si'))]
        book = ET.fromstring(z.read('xl/workbook.xml'))
        links = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target_map = {e.get('Id'):e.get('Target') for e in links.findall('{'+PKG_REL+'}Relationship')}
        for sh in book.find(q('sheets')):
            name = sh.get('name')
            targ = target_map[sh.get('{'+REL+'}id')]
            location = targ.lstrip('/') if targ.startswith('/') else posixpath.normpath(posixpath.join('xl',targ))
            root = ET.fromstring(z.read(location))
            rows = []
            for row in root.iter(q('row')):
                cells = {}
                for cell in row.findall(q('c')):
                    ref = cell.get('r','')
                    m = re.match(r'([A-Z]+)',ref)
                    if not m: continue
                    col = 0
                    for ch in m.group(1): col = col*26+ord(ch)-64
                    typ = cell.get('t')
                    raw = cell.find(q('v'))
                    if typ == 'inlineStr':
                        node = cell.find(q('is'))
                        value = ''.join(t.text or '' for t in node.iter(q('t'))) if node is not None else ''
                    elif raw is None:
                        value = ''
                    elif typ == 's':
                        value = shared[int(raw.text)]
                    else:
                        value = raw.text or ''
                    cells[col] = str(value).strip()
                rows.append((int(row.get('r','0')),cells))
            result[name] = rows
    return result

def find_header(rows, required):
    for ridx, cells in rows:
        header = {re.sub(r'[^a-z0-9]','',v.casefold()): c for c,v in cells.items() if v}
        if set(required).issubset(header):
            return ridx,header
    raise ValueError('Missing spreadsheet columns: '+', '.join(required))

def sheet_rows(path, sheet_name, columns):
    tabs = read_xlsx(path)
    if sheet_name not in tabs:
        raise ValueError(f'Expected worksheet {sheet_name!r}.')
    header_row,header = find_header(tabs[sheet_name], columns)
    values=[]
    for r, cells in tabs[sheet_name]:
        if r <= header_row or not any(cells.values()):continue
        values.append((r,{k:cells.get(v,'') for k,v in header.items()}))
    return values,tabs


class AdminMixin:
    def init_admin_schema(self):
        with self.conn:
            self.conn.executescript('''
              CREATE TABLE IF NOT EXISTS roster_changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT, cadet_id INTEGER, changed_at TEXT NOT NULL,
                previous TEXT NOT NULL, updated TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS cadet_heights (
                cadet_id INTEGER PRIMARY KEY REFERENCES cadets(id) ON DELETE CASCADE,
                height_inches INTEGER NOT NULL DEFAULT 0,
                verification TEXT NOT NULL DEFAULT 'Unverified', updated_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS memberships (
                cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                category TEXT NOT NULL, role TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(cadet_id,category));
              CREATE TABLE IF NOT EXISTS event_details (
                event_id INTEGER PRIMARY KEY REFERENCES events(id) ON DELETE CASCADE,
                event_date TEXT NOT NULL DEFAULT '', start_time TEXT NOT NULL DEFAULT '',
                end_time TEXT NOT NULL DEFAULT '', muster_time TEXT NOT NULL DEFAULT '');
              CREATE TABLE IF NOT EXISTS event_submissions (
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                status TEXT NOT NULL, support_role TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL, PRIMARY KEY(event_id,cadet_id));
              CREATE TABLE IF NOT EXISTS official_excusals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                activity TEXT NOT NULL, description TEXT NOT NULL,
                starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
                assessment TEXT NOT NULL, source_line INTEGER NOT NULL);
              CREATE TABLE IF NOT EXISTS event_decisions (
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                final_status TEXT NOT NULL, reviewer TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '', decided_at TEXT NOT NULL,
                reviewed_submission TEXT NOT NULL DEFAULT 'Attending',
                reviewed_official TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(event_id,cadet_id));
              CREATE TABLE IF NOT EXISTS event_cases (
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                cadet_id INTEGER NOT NULL REFERENCES cadets(id) ON DELETE CASCADE,
                reason TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(event_id,cadet_id,reason));
              CREATE TABLE IF NOT EXISTS attendance_imports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                imported_at TEXT NOT NULL, filename TEXT NOT NULL,
                sha256 TEXT NOT NULL, changed INTEGER NOT NULL,
                issues INTEGER NOT NULL);
              CREATE TABLE IF NOT EXISTS attendance_changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                cadet_id INTEGER REFERENCES cadets(id) ON DELETE SET NULL,
                previous_status TEXT NOT NULL, next_status TEXT NOT NULL,
                source TEXT NOT NULL, changed_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS formation_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
                revision INTEGER NOT NULL, saved_at TEXT NOT NULL,
                payload TEXT NOT NULL, UNIQUE(event_id,revision));
            ''')
            existing_cols={r[1] for r in self.conn.execute('PRAGMA table_info(event_decisions)')}
            if 'reviewed_submission' not in existing_cols:
                self.conn.execute("ALTER TABLE event_decisions ADD COLUMN reviewed_submission TEXT NOT NULL DEFAULT 'Attending'")
            if 'reviewed_official' not in existing_cols:
                self.conn.execute("ALTER TABLE event_decisions ADD COLUMN reviewed_official TEXT NOT NULL DEFAULT ''")
            self.conn.execute('''INSERT OR IGNORE INTO cadet_heights(cadet_id,height_inches,verification,updated_at)
                                SELECT id,height_inches,'Legacy',? FROM cadets''',(now(),))
            self.conn.execute("UPDATE event_submissions SET status='Other' WHERE status='Other / Review'")
            self.conn.execute('''INSERT OR IGNORE INTO memberships(cadet_id,category,role)
                                SELECT id,'Pipe Band','' FROM cadets WHERE company='PIPE' ''')
            # Preserve existing v5.2.1 event-level No values on first upgrade.
            # Modern workbook submissions, when present, always take priority.
            self.conn.execute('''INSERT OR IGNORE INTO event_submissions
                (event_id,cadet_id,status,support_role,updated_at)
                SELECT a.event_id,a.cadet_id,'Excused','',?
                FROM attendance a WHERE a.attending=0 AND NOT EXISTS
                (SELECT 1 FROM event_submissions s WHERE s.event_id=a.event_id AND s.cadet_id=a.cadet_id)''',
                (now(),))

    def set_event_details(self,event_id,event_date='',start_time='',end_time='',muster_time=''):
        if event_date:
            date.fromisoformat(event_date)
        for v in (start_time,end_time,muster_time):
            if v: time.fromisoformat(v)
        with self.conn:
            self.conn.execute('''INSERT INTO event_details(event_id,event_date,start_time,end_time,muster_time)
                 VALUES(?,?,?,?,?) ON CONFLICT(event_id) DO UPDATE SET event_date=excluded.event_date,
                 start_time=excluded.start_time,end_time=excluded.end_time,muster_time=excluded.muster_time''',
                 (event_id,event_date,start_time,end_time,muster_time))

    def get_event_details(self,event_id):
        row=self.conn.execute('SELECT event_date,start_time,end_time,muster_time FROM event_details WHERE event_id=?',(event_id,)).fetchone()
        return dict(zip(('event_date','start_time','end_time','muster_time'),row or ('','','','')))

    def export_master_roster(self,path):
        """Master roster export has NO height, attendance or medical fields."""
        groups=dict(self.conn.execute('SELECT key,name FROM formation_groups'))
        rows=[['MASTER CADET ROSTER'],
              ['Admin only: name, class, home company and role. Height and attendance are stored separately.'],
              [],['Cadet ID','Name','Class','Home Company','Role']]
        cadets=self.conn.execute('SELECT id,name,cadet_class,company,role FROM cadets').fetchall()
        for cid,name,cls,co,role in sorted(cadets,key=lambda r:(class_order(r[2]),last_name_first(r[1]).casefold(),r[0])):
            rows.append([cid,name,cls,groups.get(co,co),role])
        write_xlsx(path,[{'name':'Master Roster','rows':rows,'header_row':4,
                         'widths':[15,36,12,23,21],'filter':True,'class_band':True}])

    def preview_master_import(self,path):
        entries,_=sheet_rows(path,'Master Roster',{'name','class','homecompany'})
        known={r[0]:r for r in self.conn.execute('SELECT id,name,cadet_class,company,role FROM cadets')}
        matched=set();updates=[];added=[];issues=[]
        for rn,e in entries:
            try:
                name=' '.join(e.get('name','').split())
                if not name:raise ValueError('Missing name')
                cls=e.get('class','').strip()
                role=e.get('role','').strip() or 'Member'
                co=self.resolve_group(e.get('homecompany',''),create=False)
                raw=e.get('cadetid','')
                cid=int(raw) if raw else None
                if cid is not None:
                    if cid not in known:raise ValueError(f'Cadet ID {cid} not in master roster')
                else:
                    possibilities=[p[0] for p in known.values() if norm_name(p[1])==norm_name(name) and class_order(p[2])==class_order(cls)]
                    if len(possibilities)>1:raise ValueError('Duplicate cadet name and class; provide stable ID')
                    cid=possibilities[0] if possibilities else None
                if cid is not None:
                    if cid in matched:raise ValueError(f'Duplicate cadet ID {cid}')
                    matched.add(cid)
                    current=known[cid]
                    if (name,cls,co,role)!=(current[1],current[2],current[3],current[4]):
                        updates.append((cid,name,cls,co,role))
                else:
                    added.append((name,cls,co,role))
            except (ValueError,TypeError) as err:issues.append(f'Row {rn}: {err}')
        missing=len(set(known)-matched)
        return {'updates':updates,'added':added,'issues':issues,'missing':missing,'total':len(entries)}

    def apply_master_import(self,preview):
        if preview['issues']:
            raise ValueError('Fix master roster issues before importing:\n'+'\n'.join(preview['issues'][:14]))
        if preview['updates'] or preview['added']:
            self.backup_database('master_roster_import')
        with self.conn:
            for cid,name,cls,co,role in preview['updates']:
                prior=self.conn.execute('SELECT name,cadet_class,company,role FROM cadets WHERE id=?',(cid,)).fetchone()
                self.conn.execute('UPDATE cadets SET name=?,cadet_class=?,company=?,role=? WHERE id=?',
                                  (name,cls,co,role,cid))
                self.conn.execute('INSERT INTO roster_changes(cadet_id,changed_at,previous,updated) VALUES(?,?,?,?)',
                                  (cid,now(),json.dumps(prior),json.dumps((name,cls,co,role))))
            for name,cls,co,role in preview['added']:
                cid=self.conn.execute('INSERT INTO cadets(name,cadet_class,company,role,height_inches) VALUES(?,?,?,?,0)',
                                      (name,cls,co,role)).lastrowid
                self.conn.execute('INSERT INTO cadet_heights(cadet_id,height_inches,verification,updated_at) VALUES(?,?,?,?)',
                                  (cid,0,'Unverified',now()))
                self.conn.execute('INSERT INTO roster_changes(cadet_id,changed_at,previous,updated) VALUES(?,?,?,?)',
                                  (cid,now(),'New cadet',json.dumps((name,cls,co,role))))
        return len(preview['added']),len(preview['updates'])

    def height_records(self):
        return self.conn.execute('''SELECT c.id,c.name,c.cadet_class,c.company,h.height_inches,h.verification
             FROM cadets c LEFT JOIN cadet_heights h ON h.cadet_id=c.id ORDER BY c.name COLLATE NOCASE''').fetchall()

    def update_height(self,cadet_id,height,verification='Verified'):
        if not isinstance(height,int) or height < 0 or height > 108 or (height and height < 36):
            raise ValueError('Enter a valid height in total inches (36–108), or 0 if unknown.')
        if verification not in ('Verified','Estimated','Unverified','Legacy','Manual'):
            raise ValueError('Invalid height verification label.')
        with self.conn:
            self.conn.execute('''INSERT INTO cadet_heights(cadet_id,height_inches,verification,updated_at)
                 VALUES(?,?,?,?) ON CONFLICT(cadet_id) DO UPDATE SET height_inches=excluded.height_inches,
                 verification=excluded.verification,updated_at=excluded.updated_at''',
                 (cadet_id,height,verification,now()))
            self.conn.execute('UPDATE cadets SET height_inches=? WHERE id=?',(height,cadet_id))

    def export_heights(self,path):
        rows=[['Height Administration'],['Only edit Feet, Inches and Verification. IDs identify cadets uniquely.'],
              [],['Cadet ID','Name','Class','Home Company','Feet','Inches','Verification']]
        for cid,name,cls,co,h,ver in self.height_records():
            ft,inch=divmod(h,12) if h else ('','')
            rows.append([cid,name,cls,co,ft,inch,ver])
        write_xlsx(path,[{'name':'Height Data','rows':rows,'header_row':4,
                          'widths':[14,32,12,20,11,11,18], 'filter':True}])

    def preview_height_import(self,path):
        entries,_=sheet_rows(path,'Height Data',{'cadetid','feet','inches','verification'})
        lookup={r[0]:r for r in self.height_records()}
        updates=[];issues=[];seen=set()
        for rn,e in entries:
            try:
                cid=int(e['cadetid'])
                if cid in seen:raise ValueError('Duplicate cadet ID')
                seen.add(cid)
                if cid not in lookup:raise ValueError('Unknown cadet ID')
                prior=lookup[cid]
                if e.get('name') and norm_name(e['name'])!=norm_name(prior[1]):
                    raise ValueError('Name and ID disagree')
                feet=e.get('feet',''); inch=e.get('inches','')
                height=0 if not feet and not inch else int(feet or '0')*12+int(inch or '0')
                if height and not 36<=height<=108:raise ValueError('Height outside 3–9 feet')
                if inch and not 0<=int(inch)<12:raise ValueError('Inches must be 0–11')
                ver=e.get('verification','').strip() or ('Unverified' if not height else 'Verified')
                if ver not in ('Verified','Estimated','Unverified','Legacy','Manual'):
                    raise ValueError('Unknown verification label')
                if height!=prior[4] or ver!=prior[5]: updates.append((cid,height,ver))
            except (ValueError,KeyError,TypeError) as ex: issues.append(f'Row {rn}: {ex}')
        return {'updates':updates,'issues':issues,'total':len(entries)}

    def apply_height_import(self,preview):
        if preview['issues']:
            raise ValueError('Fix height import issues before applying changes:\n'+'\n'.join(preview['issues'][:10]))
        if preview['updates']:
            self.backup_database('height_import')
        with self.conn:
            for cid,h,v in preview['updates']:
                self.conn.execute('''INSERT INTO cadet_heights(cadet_id,height_inches,verification,updated_at)
                      VALUES(?,?,?,?) ON CONFLICT(cadet_id) DO UPDATE SET height_inches=excluded.height_inches,
                      verification=excluded.verification,updated_at=excluded.updated_at''',(cid,h,v,now()))
                self.conn.execute('UPDATE cadets SET height_inches=? WHERE id=?',(h,cid))
        return len(preview['updates'])





    def export_attendance(self,event_id,path):
        """Export one easy-to-edit worksheet per company for the selected event.

        Only the status column is intended for cadet editing.  IDs are included
        but hidden, so a re-import is more resilient than a name-only workbook.
        """
        event=self.conn.execute('SELECT name FROM events WHERE id=?',(event_id,)).fetchone()
        if not event:raise ValueError('Unknown event')
        details=self.get_event_details(event_id)
        groups=dict(self.conn.execute('SELECT key,name FROM formation_groups'))
        people=self.conn.execute('SELECT id,name,cadet_class,company FROM cadets').fetchall()
        by_group={}
        for cid,name,cls,co in people:
            by_group.setdefault(co,[]).append((cid,name,cls,co))
        standard=('Alpha','Bravo','Charlie','Delta','Echo','Foxtrot','Golf','Hotel')
        group_keys=sorted(by_group,key=lambda k:(standard.index(groups.get(k,k)) if groups.get(k,k) in standard else 100,
                                                  groups.get(k,k).casefold()))
        submission=dict(self.conn.execute('SELECT cadet_id,status FROM event_submissions WHERE event_id=?',(event_id,)))
        sheets=[];used=set()
        for key in group_keys:
            name=groups.get(key,key)
            # Excel limits worksheet names to 31 characters.  Resolve rare
            # same-prefix collisions without altering the authoritative group.
            tab=re.sub(r'[\[\]\*\?/\\:]', '_',name)[:31] or 'Company'
            stem=tab;number=2
            while tab.casefold() in used:
                suffix=f' {number}';tab=stem[:31-len(suffix)]+suffix;number+=1
            used.add(tab.casefold())
            rows=[[f'{name.upper()} COMPANY | {event[0]}'],
                  [f'Event: {event[0]}',f'Date: {details["event_date"]}',
                   f'Start: {details["start_time"]}',f'Muster: {details["muster_time"]}'],
                  ['Find your name (Ctrl+F), then change ONLY the Attendance Status dropdown if needed.'],
                  [],['Cadet ID','Class','Cadet (last, first)','Home Company','Attendance Status']]
            ordered=sorted(by_group[key],key=lambda p:(class_order(p[2]),last_name_first(p[1]).casefold(),p[0]))
            for cid,person,cls,co in ordered:
                rows.append([cid,cls,last_name_first(person),name,submission.get(cid,'Attending')])
            sheets.append({'name':tab,'rows':rows,'header_row':5,'dropdown_col':5,
                           'widths':[12,12,36,20,24],'hidden_cols':[1],
                           'filter':True,'class_band':True,'protected':True,'editable_cols':[5]})
        meta=[['Formation Planner Attendance','4'],['Event ID',event_id],
              ['Event Name',event[0]],['Date',details['event_date']],
              ['Workbook Layout','Separate company tabs'],['Created At',now()]]
        sheets.append({'name':'Metadata','rows':meta,'hidden':True,'widths':[30,45]})
        write_xlsx(path,sheets)

    def preview_attendance(self,event_id,path):
        """Accept v5.2.3 single-tab files and the eight-tab Corps workbook.

        For company tabs with blank Cadet IDs, match name + class + home
        company first.  If that fails, a unique exact name + class can match
        a cadet kept under a separate group (e.g. Regimental Staff) or with
        an older company assignment. Report each such match before applying;
        NEVER update the permanent roster or height data. Ambiguity fails.
        """
        if not self.conn.execute('SELECT 1 FROM events WHERE id=?',(event_id,)).fetchone():
            raise ValueError('Select a valid event before importing attendance.')
        tabs=read_xlsx(path)
        metadata={c.get(1,''):c.get(2,'') for _,c in tabs.get('Metadata',[]) if c.get(1,'')}
        is_classic='Attendance' in tabs
        source_event=str(metadata.get('Event ID','')).strip()
        if is_classic:
            if source_event!=str(event_id):
                raise ValueError('This attendance workbook belongs to a different event. No changes made.')
            tab_specs=[('Attendance',None)]
        else:
            # Templates with no event binding can be reused for the currently
            # selected event. A file actually exported for another event cannot.
            if source_event and source_event not in ('UNBOUND_TEMPLATE',str(event_id)):
                raise ValueError('This attendance workbook belongs to a different event. No changes made.')
            valid_groups={v.casefold():k for k,v in self.conn.execute('SELECT key,name FROM formation_groups')}
            valid_groups.update({k.casefold():k for k, in self.conn.execute('SELECT key FROM formation_groups')})
            tab_specs=[];seen_groups=set()
            for tab_name in tabs:
                if tab_name.casefold()=='metadata':continue
                group_key=valid_groups.get(tab_name.casefold())
                if group_key is None:
                    # Ignore optional sheets that do not look like a company
                    # roster, but never ignore a company-shaped unknown sheet.
                    try:find_header(tabs[tab_name],{'cadetlastfirst','attendancestatus'})
                    except ValueError:continue
                    raise ValueError(f'Unknown company tab {tab_name!r}. Rename it to the existing home company.')
                if group_key in seen_groups:
                    raise ValueError(f'Duplicate company tab for {tab_name}.')
                seen_groups.add(group_key)
                tab_specs.append((tab_name,group_key))
            if not tab_specs:
                raise ValueError('No company tabs found. Expected Alpha through Hotel or a single Attendance tab.')

        known={r[0]:r for r in self.conn.execute('SELECT id,name,cadet_class,company FROM cadets')}
        group_lookup={v.casefold():k for k,v in self.conn.execute('SELECT key,name FROM formation_groups')}
        group_lookup.update({k.casefold():k for k, in self.conn.execute('SELECT key FROM formation_groups')})
        by_identity={}
        by_name_class={}
        for cid,name,cls,co in known.values():
            parsed_class=class_order(cls)
            normalized=norm_name(name)
            by_identity.setdefault((co,parsed_class,normalized),[]).append(cid)
            by_name_class.setdefault((parsed_class,normalized),[]).append(cid)
        prior={cid:(status,role) for cid,status,role in self.conn.execute(
            'SELECT cadet_id,status,support_role FROM event_submissions WHERE event_id=?',(event_id,))}
        seen=set();changes=[];issues=[];warnings=[];total=0
        for tab_name,tab_group in tab_specs:
            try:
                header_row,header=find_header(tabs[tab_name],{'cadetlastfirst','attendancestatus'})
            except ValueError as exc:
                issues.append(f'{tab_name}: {exc}');continue
            for rn,cells in tabs[tab_name]:
                if rn<=header_row or not any(cells.values()):continue
                total+=1
                e={key:cells.get(col,'') for key,col in header.items()}
                label=f'{tab_name} row {rn}'
                try:
                    name=e.get('cadetlastfirst','').strip()
                    if not name:raise ValueError('Missing cadet name')
                    cls=e.get('class','').strip()
                    co=e.get('homecompany','').strip()
                    company=group_lookup.get(co.casefold()) if co else tab_group
                    if company is None:raise ValueError(f'Unknown home company {co!r}')
                    if tab_group is not None and company!=tab_group:
                        raise ValueError(f'Home company {co!r} disagrees with {tab_name} tab')
                    raw_id=e.get('cadetid','').strip()
                    matched_other_company=False
                    if raw_id:
                        cid=int(raw_id)
                        if cid not in known:raise ValueError(f'Unknown Cadet ID {cid}')
                    else:
                        if not is_classic:
                            if not cls:raise ValueError('Missing class; cannot safely match without an ID')
                            parsed_class=class_order(cls)
                            normalized=norm_name(name)
                            possibilities=by_identity.get((company,parsed_class,normalized),[])
                            if not possibilities:
                                # E.g. the Corps sheet uses home company Alpha
                                # but the saved registry places the cadet in
                                # Regimental Staff. Match ONLY an exact, unique
                                # name AND class; never guess from fuzzy names.
                                possibilities=by_name_class.get((parsed_class,normalized),[])
                                matched_other_company=bool(possibilities)
                            if not possibilities:
                                raise ValueError(f'{name} ({cls}, {co or tab_name}): no exact matching name and class in the Master Roster')
                            if len(possibilities)>1:
                                raise ValueError(f'Multiple matching cadets for {name} ({cls}); resolve using app-exported IDs')
                            cid=possibilities[0]
                        else:raise ValueError('Missing Cadet ID in original single-tab workbook')
                    if cid in seen:raise ValueError('Duplicate cadet across attendance tabs')
                    # Mark seen only for valid records; duplicate invalid rows
                    # will still be surfaced in the explicit issue list.
                    _,actual_name,actual_cls,actual_group=known[cid]
                    if norm_name(name)!=norm_name(actual_name):
                        raise ValueError(f'Name does not match cadet {cid}')
                    if cls and class_order(cls)!=class_order(actual_cls):
                        raise ValueError(f'Class mismatch for {actual_name}')
                    if co or tab_group is not None:
                        if company!=actual_group:
                            if not matched_other_company:
                                raise ValueError(f'Home company mismatch for {actual_name}')
                    status=e.get('attendancestatus','').strip()
                    if status=='Other / Review':status='Other'
                    if status not in STATUS_CHOICES:
                        raise ValueError(f'Invalid attendance status {status!r}; choose from the dropdown')
                    role=e.get('supportrole','').strip() if is_classic else ''
                    old=prior.get(cid,('Attending',''))
                    if (status,role)!=old:changes.append((cid,old[0],status,old[1],role))
                    if matched_other_company:
                        saved_group=next((n for k,n in self.conn.execute('SELECT key,name FROM formation_groups') if k==actual_group),actual_group)
                        warnings.append(f'{label}: {actual_name} ({actual_cls}) is in the saved {saved_group} roster; attendance matched by name/class. Permanent company was not changed.')
                    seen.add(cid)
                except (ValueError,TypeError,KeyError) as exc:
                    issues.append(f'{label}: {exc}')
        missing=set(known)-seen
        if missing:issues.append(f'{len(missing)} cadets missing/unmatched in workbook; import a matching Master Roster or re-export.')
        digest=hashlib.sha256(Path(path).read_bytes()).hexdigest()
        return {'changes':changes,'issues':issues,'warnings':warnings,'total':total,'hash':digest,'filename':Path(path).name,
                'layout':'single' if is_classic else 'company',
                'unbound':not is_classic and source_event in ('','UNBOUND_TEMPLATE'),
                'already_imported':bool(self.conn.execute(
                    'SELECT 1 FROM attendance_imports WHERE event_id=? AND sha256=?',(event_id,digest)).fetchone())}

    def apply_attendance(self,event_id,preview):
        if preview['issues']:raise ValueError('Fix attendance workbook issues before importing:\n'+'\n'.join(preview['issues'][:12]))
        if preview['already_imported']:return 0
        if preview['changes']:self.backup_database('attendance_import')
        with self.conn:
            for cid,old,new,oldrole,newrole in preview['changes']:
                self.conn.execute('''INSERT INTO event_submissions(event_id,cadet_id,status,support_role,updated_at)
                    VALUES(?,?,?,?,?) ON CONFLICT(event_id,cadet_id) DO UPDATE SET
                    status=excluded.status,support_role=excluded.support_role,updated_at=excluded.updated_at''',
                    (event_id,cid,new,newrole,now()))
                self.conn.execute('''INSERT INTO attendance_changes(event_id,cadet_id,previous_status,next_status,source,changed_at)
                    VALUES(?,?,?,?,?,?)''',(event_id,cid,old,new,'Excel',now()))
            self.conn.execute('''INSERT INTO attendance_imports(event_id,imported_at,filename,sha256,changed,issues)
                VALUES(?,?,?,?,?,0)''',(event_id,now(),preview['filename'],preview['hash'],len(preview['changes'])))
        self.reconcile_event(event_id)
        return len(preview['changes'])

    def set_submitted_status(self,event_id,cadet_id,status,support_role=''):
        """Update this event status; only Attending joins company march-on."""
        if status not in STATUS_CHOICES:
            raise ValueError('Choose a valid attendance status.')
        existing=self.conn.execute('SELECT status FROM event_submissions WHERE event_id=? AND cadet_id=?',
                                   (event_id,cadet_id)).fetchone()
        old=existing[0] if existing else 'Attending'
        with self.conn:
            self.conn.execute('''INSERT INTO event_submissions(event_id,cadet_id,status,support_role,updated_at)
                VALUES(?,?,?,?,?) ON CONFLICT(event_id,cadet_id) DO UPDATE SET status=excluded.status,
                support_role=excluded.support_role,updated_at=excluded.updated_at''',(event_id,cadet_id,status,support_role,now()))
            self.conn.execute('''INSERT INTO attendance_changes(event_id,cadet_id,previous_status,next_status,source,changed_at)
                VALUES(?,?,?,?,?,?)''',(event_id,cadet_id,old,status,'Manual submission',now()))
        self.reconcile_event(event_id)





    def reconcile_event(self,event_id):
        """Attending marches; every other status is excluded."""
        with self.conn:
            self.conn.execute('''INSERT INTO attendance(event_id,cadet_id,attending)
                SELECT ?,c.id,CASE WHEN COALESCE(s.status,'Attending')='Attending' THEN 1 ELSE 0 END
                FROM cadets c LEFT JOIN event_submissions s
                  ON s.cadet_id=c.id AND s.event_id=?
                WHERE 1
                ON CONFLICT(event_id,cadet_id) DO UPDATE SET attending=excluded.attending''',
                (event_id,event_id))

    def cases(self,event_id):
        return self.conn.execute('''SELECT x.cadet_id,c.name,c.cadet_class,c.company,x.reason,x.details,
                COALESCE(s.status,'Attending') FROM event_cases x JOIN cadets c ON c.id=x.cadet_id
                LEFT JOIN event_submissions s ON s.event_id=x.event_id AND s.cadet_id=x.cadet_id
                WHERE x.event_id=? ORDER BY c.company,c.name COLLATE NOCASE,x.reason''',(event_id,)).fetchall()


    def status_summary(self,event_id):
        records=self.conn.execute('''SELECT c.id,COALESCE(s.status,'Attending')
           FROM cadets c LEFT JOIN event_submissions s
           ON s.cadet_id=c.id AND s.event_id=?''',(event_id,)).fetchall()
        counts=Counter(status for _,status in records)
        counts['Not marching']=sum(1 for _,status in records if status!='Attending')
        counts['Company march-on']=sum(1 for p in self.roster(event_id)
             if p.attending and p.group not in ('PIPE','FOOT','SUPPORT')
             and p.role.casefold() in ('','member','formation'))
        return counts

    def export_event_report(self,event_id,path):
        statuses={cid:(status,role) for cid,status,role in self.conn.execute(
            'SELECT cadet_id,status,support_role FROM event_submissions WHERE event_id=?',(event_id,))}
        groups=dict(self.conn.execute('SELECT key,name FROM formation_groups'))
        people=self.conn.execute('SELECT id,name,cadet_class,company,role FROM cadets ORDER BY name COLLATE NOCASE').fetchall()
        with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f)
            writer.writerow(['Cadet ID','Name','Class','Home Company','Attendance Status','Marches With Company'])
            for cid,name,cls,co,rank_role in people:
                selected=statuses.get(cid,('Attending',''))[0]
                marches=(selected=='Attending' and co not in ('PIPE','FOOT','SUPPORT')
                         and rank_role.casefold() in ('','member','formation'))
                writer.writerow([cid,name,cls,groups.get(co,co),selected,'YES' if marches else 'NO'])

    def formation_history(self,event_id):
        return self.conn.execute('SELECT revision,saved_at FROM formation_versions WHERE event_id=? ORDER BY revision DESC',(event_id,)).fetchall()

    def save_formation_snapshot(self,event_id,formations,settings):
        sections=[]
        for formation in formations:
            def snap(p):
                return {'id':p.id,'name':p.name,'group':p.group,'height_inches':p.height_inches,
                        'attending':p.attending,'role':p.role,'cadet_class':p.cadet_class}
            sections.append({'key':formation.group.key,'name':formation.group.name,
                             'members':[snap(p) for p in formation.members],
                             'leaders':[snap(p) for p in formation.leaders]})
        payload=json.dumps({'sections':sections,'settings':settings})
        with self.conn:
            revision=self.conn.execute('SELECT COALESCE(MAX(revision),0)+1 FROM formation_versions WHERE event_id=?',(event_id,)).fetchone()[0]
            self.conn.execute('INSERT INTO formation_versions(event_id,revision,saved_at,payload) VALUES(?,?,?,?)',
                              (event_id,revision,now(),payload))
        return revision

    def load_formation_snapshot(self,event_id,revision=None):
        if revision is None:
            row=self.conn.execute('SELECT revision,payload FROM formation_versions WHERE event_id=? ORDER BY revision DESC LIMIT 1',(event_id,)).fetchone()
        else:
            row=self.conn.execute('SELECT revision,payload FROM formation_versions WHERE event_id=? AND revision=?',(event_id,revision)).fetchone()
        if not row:return None
        return row[0],json.loads(row[1])

    def restore_formation_snapshot(self,event_id,revision):
        source=self.load_formation_snapshot(event_id,revision)
        if source is None:raise ValueError('Formation revision does not exist.')
        with self.conn:
            new=self.conn.execute('SELECT COALESCE(MAX(revision),0)+1 FROM formation_versions WHERE event_id=?',(event_id,)).fetchone()[0]
            self.conn.execute('INSERT INTO formation_versions(event_id,revision,saved_at,payload) VALUES(?,?,?,?)',
                              (event_id,new,now(),json.dumps(source[1])))
        return new
