"""Compact administrative windows for Formation Planner v5.2.6.

All operations run locally.  Cadets access exported XLSX files; the application
never sends email, automatically reads cloud sheets, or grants network access.
"""
import sqlite3
import tkinter as tk
from pathlib import Path
from tkinter import ttk, filedialog, messagebox, simpledialog
from admin_backend import STATUS_CHOICES, last_name_first


def action(parent,fn):
    try:return fn()
    except (ValueError, OSError, sqlite3.Error, KeyError, IndexError) as exc:
        messagebox.showerror('Operation could not be completed',str(exc),parent=parent)
        return None


def build_tree(parent,cols,widths=None,height=10):
    frame=ttk.Frame(parent)
    frame.pack(fill='both',expand=True,padx=8,pady=5)
    tree=ttk.Treeview(frame,columns=cols,show='headings',selectmode='browse',height=height)
    widths=widths or {}
    for col in cols:
        tree.heading(col,text=col)
        tree.column(col,width=widths.get(col,130),minwidth=65,stretch=col in ('Name','Detail','Reason'))
    y=ttk.Scrollbar(frame,orient='vertical',command=tree.yview)
    x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
    tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
    tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
    frame.grid_rowconfigure(0,weight=1);frame.grid_columnconfigure(0,weight=1)
    return tree

class AdminDashboard(tk.Toplevel):
    def __init__(self,app,initial_tab='Attendance'):
        super().__init__(app)
        self.app=app;self.db=app.db;self.event_id=app.event_id
        event_name=next((n for i,n in self.db.events() if i==self.event_id),'Current Event')
        self.title('Formation Planner | '+event_name)
        sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
        width=min(1040,max(760,sw-65));height=min(760,max(500,sh-100))
        self.geometry(f'{width}x{height}+35+35')
        self.minsize(min(700,width),min(470,height))
        self.configure(bg='#f2f6f9')
        title=ttk.Frame(self,padding=(12,10));title.pack(fill='x')
        ttk.Label(title,text='ATTENDANCE & ROSTER',font=('Arial',15,'bold')).pack(side='left')
        ttk.Label(title,text='  '+event_name,foreground='#527085').pack(side='left',padx=8)
        ttk.Button(title,text='Refresh all',command=self.refresh_all).pack(side='right')
        self.tabs=ttk.Notebook(self)
        self.tabs.pack(fill='both',expand=True,padx=10,pady=(0,8))
        self.tab_map={}
        for name in ('Attendance','Not Marching','Roster','Heights','History'):
            frame=ttk.Frame(self.tabs,padding=6)
            self.tabs.add(frame,text=name)
            self.tab_map[name]=frame
        self._build_event(self.tab_map['Attendance'])
        self._build_not_marching(self.tab_map['Not Marching'])
        self._build_master_roster(self.tab_map['Roster'])
        self._build_heights(self.tab_map['Heights'])
        self._build_history(self.tab_map['History'])
        self.status=tk.StringVar(value='Everyone defaults to Attending. Only selected event changes on import.')
        ttk.Label(self,textvariable=self.status,foreground='#527085',padding=8,wraplength=850).pack(anchor='w')
        self.refresh_all()
        if initial_tab in self.tab_map:
            self.tabs.select(self.tab_map[initial_tab])

    def _build_event(self,tab):
        # The classic laptop build must keep EVERY administrative action
        # reachable at 1024x600.  Scroll rather than clipping lower controls.
        canvas=tk.Canvas(tab,background='#f2f6f9',highlightthickness=0)
        vs=ttk.Scrollbar(tab,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=vs.set)
        canvas.pack(side='left',fill='both',expand=True)
        vs.pack(side='right',fill='y')
        body=ttk.Frame(canvas)
        window=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
        def wheel(event):
            direction=-1 if getattr(event,'delta',0)>0 or getattr(event,'num',0)==4 else 1
            canvas.yview_scroll(direction*3,'units')
        canvas.bind('<MouseWheel>',wheel)
        canvas.bind('<Button-4>',wheel)
        canvas.bind('<Button-5>',wheel)
        for widget in (body,):
            widget.bind('<MouseWheel>',wheel)
        tab=body
        details=ttk.LabelFrame(tab,text='Event date and time (optional)',padding=8)
        details.pack(fill='x',padx=5,pady=5)
        v=self.db.get_event_details(self.event_id)
        self.date=tk.StringVar(value=v['event_date'])
        self.start=tk.StringVar(value=v['start_time'])
        self.end=tk.StringVar(value=v['end_time'])
        self.muster=tk.StringVar(value=v['muster_time'])
        ttk.Label(details,text='Date YYYY-MM-DD').grid(row=0,column=0,sticky='w',padx=4)
        ttk.Entry(details,textvariable=self.date,width=16).grid(row=0,column=1,sticky='w',padx=4)
        ttk.Label(details,text='Event start HH:MM').grid(row=0,column=2,sticky='w',padx=4)
        ttk.Entry(details,textvariable=self.start,width=10).grid(row=0,column=3,sticky='w',padx=4)
        ttk.Label(details,text='End HH:MM').grid(row=1,column=0,sticky='w',padx=4,pady=5)
        ttk.Entry(details,textvariable=self.end,width=16).grid(row=1,column=1,sticky='w',padx=4)
        ttk.Label(details,text='Muster HH:MM').grid(row=1,column=2,sticky='w',padx=4)
        ttk.Entry(details,textvariable=self.muster,width=10).grid(row=1,column=3,sticky='w',padx=4)
        ttk.Button(details,text='Save schedule',command=self.save_schedule).grid(row=0,column=4,rowspan=2,padx=15)
        ttk.Label(tab,text='Each event gets an Excel workbook with one tab per company. All statuses start as Attending. '
                 'Cadets only change the Attendance Status dropdown.',
                 wraplength=900,foreground='#42647a').pack(fill='x',padx=9,pady=8)
        buttons=ttk.LabelFrame(tab,text='Attendance files',padding=9);buttons.pack(fill='x',padx=5,pady=6)
        for pos,(text,command) in enumerate((
            ('1. Export Corps Attendance (.xlsx)',self.export_attendance),
            ('2. Import Updated Attendance (.xlsx)',self.import_attendance),
            ('Export Attendance Report (.csv)',self.export_report))):
            ttk.Button(buttons,text=text,command=command).grid(row=pos//2,column=pos%2,sticky='ew',padx=5,pady=3)
        buttons.columnconfigure(0,weight=1);buttons.columnconfigure(1,weight=1)
        panel=ttk.LabelFrame(tab,text='Attendance summary',padding=12);panel.pack(fill='x',padx=5,pady=9)
        self.summary=tk.StringVar()
        ttk.Label(panel,textvariable=self.summary,font=('Arial',11),justify='left',wraplength=880).pack(anchor='w')
        manual=ttk.LabelFrame(tab,text='Admin correction / quick status lookup',padding=8)
        manual.pack(fill='x',padx=5,pady=5)
        ttk.Label(manual,text='Cadet').pack(side='left')
        self.cadet_lookup=tk.StringVar()
        self.cadet_combo=ttk.Combobox(manual,textvariable=self.cadet_lookup,width=34)
        self.cadet_combo.pack(side='left',padx=5)
        self.cadet_lookup.trace_add('write',lambda *_:self._update_cadet_suggestions(self.cadet_combo,self.cadet_lookup))
        ttk.Label(manual,text='Status').pack(side='left',padx=(10,4))
        self.quick_status=tk.StringVar(value='Attending')
        ttk.Combobox(manual,textvariable=self.quick_status,values=STATUS_CHOICES,
                     state='readonly',width=18).pack(side='left')
        ttk.Button(manual,text='Change status',command=self.quick_change).pack(side='left',padx=7)

    def _build_not_marching(self,tab):
        ttk.Label(tab,text='These cadets selected a status other than Attending and are excluded from the company march-on.',
                  foreground='#446b81',wraplength=900).pack(anchor='w',padx=8,pady=8)
        self.not_marching_tree=build_tree(tab,['Name','Class','Home Company','Selected Status'],
                         {'Name':260,'Class':92,'Home Company':160,'Selected Status':200})

    def refresh_not_marching(self):
        self.not_marching_tree.delete(*self.not_marching_tree.get_children())
        groups=dict(self.db.conn.execute('SELECT key,name FROM formation_groups'))
        rows=self.db.conn.execute('''SELECT c.id,c.name,c.cadet_class,c.company,s.status
             FROM event_submissions s JOIN cadets c ON c.id=s.cadet_id
             WHERE s.event_id=? AND s.status!='Attending' ''',(self.event_id,)).fetchall()
        rows.sort(key=lambda r:(int(r[2][0]) if r[2] and r[2][0] in '1234' else 9,last_name_first(r[1]).casefold()))
        for cid,name,cls,co,status in rows:
            self.not_marching_tree.insert('','end',iid=str(cid),values=(name,cls,groups.get(co,co),status))




    def _build_master_roster(self,tab):
        ttk.Label(tab,text='This is the permanent cadet record. Editing this workbook cannot change an event attendance status or a cadet height. Missing rows are never deleted automatically.',
                 wraplength=940,foreground='#446b81').pack(fill='x',padx=8,pady=8)
        tools=ttk.Frame(tab);tools.pack(fill='x',padx=8,pady=4)
        ttk.Button(tools,text='Export Master Roster (.xlsx)',command=self.export_master).pack(side='left',padx=3)
        ttk.Button(tools,text='Import Revised Master Roster (.xlsx)',command=self.import_master).pack(side='left',padx=3)
        ttk.Button(tools,text='Open Classic Roster Editor',command=self.app.manage_roster).pack(side='left',padx=3)
        self.master_tree=build_tree(tab,['ID','Name','Class','Home Company','Role'],
                     {'ID':60,'Name':290,'Class':90,'Home Company':180,'Role':150})

    def refresh_master_roster(self):
        self.master_tree.delete(*self.master_tree.get_children())
        companies=dict(self.db.conn.execute('SELECT key,name FROM formation_groups'))
        for cid,name,cls,co,role in self.db.conn.execute('SELECT id,name,cadet_class,company,role FROM cadets ORDER BY name COLLATE NOCASE'):
            self.master_tree.insert('','end',iid=str(cid),values=(cid,name,cls,companies.get(co,co),role))

    def export_master(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.xlsx',initialfile='Master_Cadet_Roster.xlsx',
                                           filetypes=[('Excel workbook','*.xlsx')])
        if path:
            action(self,lambda:self.db.export_master_roster(path))
            self.status.set('Master Roster exported; no height or event attendance information included.')

    def import_master(self):
        path=filedialog.askopenfilename(parent=self,filetypes=[('Excel workbook','*.xlsx')])
        if not path:return
        def do():
            p=self.db.preview_master_import(path)
            if p['issues']:
                messagebox.showerror('Master roster validation','\n'.join(p['issues'][:14]),parent=self);return
            total=len(p['updates'])+len(p['added'])
            message=(f'{p["total"]} rows analyzed.\nNew cadets: {len(p["added"])}'
                     f'\nExisting cadets changed: {len(p["updates"])}'
                     f'\nExisting cadets omitted (will NOT delete): {p["missing"]}\n'
                     'Heights and event attendance will not be modified.\n\nApply changes?')
            if not messagebox.askyesno('Review master roster changes',message,parent=self):return
            added,updated=self.db.apply_master_import(p)
            self.refresh_all()
            self.status.set(f'Master roster: {added} added, {updated} updated. Existing heights and attendance preserved.')
        action(self,do)


    def _build_heights(self,tab):
        ttk.Label(tab,text='Height values are stored separately from event attendance. Verification labels are '
                  'administrative and do not appear in the Corps-wide sheet.',
                  wraplength=880,foreground='#42647a').pack(fill='x',padx=8,pady=5)
        controls=ttk.Frame(tab);controls.pack(fill='x',padx=7,pady=4)
        ttk.Button(controls,text='Export Height Database (.xlsx)',command=self.export_heights).pack(side='left',padx=4)
        ttk.Button(controls,text='Import Revised Heights (.xlsx)',command=self.import_heights).pack(side='left',padx=4)
        self.only_missing=tk.BooleanVar(value=False)
        ttk.Checkbutton(controls,text='Show missing / estimated only',variable=self.only_missing,
                        command=self.refresh_heights).pack(side='left',padx=12)
        form=ttk.LabelFrame(tab,text='Edit selected height',padding=7);form.pack(fill='x',padx=5,pady=5)
        ttk.Label(form,text='Feet').pack(side='left')
        self.ft=tk.StringVar();ttk.Entry(form,width=5,textvariable=self.ft).pack(side='left',padx=4)
        ttk.Label(form,text='Inches').pack(side='left')
        self.inches=tk.StringVar();ttk.Entry(form,width=5,textvariable=self.inches).pack(side='left',padx=4)
        self.verified=tk.StringVar(value='Verified')
        ttk.Combobox(form,textvariable=self.verified,values=('Verified','Estimated','Unverified','Legacy','Manual'),
                     state='readonly',width=15).pack(side='left',padx=9)
        ttk.Button(form,text='Save selected height',command=self.edit_height).pack(side='left')
        self.height_tree=build_tree(tab,['Name','Class','Home Company','Height','Verification'],
            {'Name':265,'Class':80,'Home Company':170,'Height':90,'Verification':160})
        self.height_tree.bind('<<TreeviewSelect>>',self.choose_height)

    def _build_history(self,tab):
        ttk.Label(tab,text='Formations are saved as independent versions. An attendance import never rearranges '
                  'a finalized formation; use Finalize / Revise in the main window to create a new revision.',
                  wraplength=880,foreground='#42647a').pack(fill='x',padx=8,pady=5)
        bar=ttk.Frame(tab);bar.pack(fill='x',padx=7,pady=3)
        ttk.Button(bar,text='Restore selected revision as NEW revision',command=self.restore_revision).pack(side='left',padx=4)
        ttk.Button(bar,text='Refresh',command=self.refresh_history).pack(side='left',padx=4)
        self.hist_tree=build_tree(tab,['Type','Revision / File','Time','Changes'],
            {'Type':125,'Revision / File':360,'Time':220,'Changes':100})

    def _update_cadet_suggestions(self,combo,var):
        q=var.get().casefold().strip()
        if not q:combo.configure(values=[]);return
        options=[]
        for p in self.app.all_people:
            text=f'{p.name} [{p.cadet_class}] #{p.id}'
            if q in p.name.casefold() or q in text.casefold():
                options.append(text)
        combo.configure(values=sorted(options,key=str.casefold)[:30])

    def _lookup_cadet(self,text):
        import re
        match=re.search(r'#(\d+)\s*$',text.strip())
        if not match:raise ValueError('Choose a cadet from the autocomplete list (includes the unique #ID).')
        cid=int(match.group(1))
        if not self.db.conn.execute('SELECT 1 FROM cadets WHERE id=?',(cid,)).fetchone():
            raise ValueError('Cadet ID no longer exists.')
        return cid

    def refresh_all(self):
        self.app.refresh()
        self._refresh_summary();self.refresh_not_marching();self.refresh_master_roster()
        self.refresh_heights();self.refresh_history()

    def _refresh_summary(self):
        c=self.db.status_summary(self.event_id)
        self.summary.set('   '.join(f'{k}: {c.get(k,0)}' for k in ('Attending','Pipe Band','Football','Game Support'))+
                         '\n'+'   '.join(f'{k}: {c.get(k,0)}' for k in ('Excused','Medical Excusal','Other'))+
                         f'\nCompany march-on: {c.get("Company march-on",0)} | Selected non-marching: {c.get("Not marching",0)}')

    def save_schedule(self):
        def do():
            self.db.set_event_details(self.event_id,self.date.get().strip(),self.start.get().strip(),
                     self.end.get().strip(),self.muster.get().strip())
            self.status.set('Event schedule saved.')
        action(self,do)

    def export_attendance(self):
        name=self.app.event_var.get().replace(' ','_')
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.xlsx',initialfile=f'{name}_Attendance.xlsx',
                                           filetypes=[('Excel workbook','*.xlsx')])
        if path:
            action(self,lambda:self.db.export_attendance(self.event_id,Path(path)))
            self.status.set('Exported company-tab attendance workbook. Share it, then download/import the completed copy.')

    def import_attendance(self):
        path=filedialog.askopenfilename(parent=self,filetypes=[('Excel workbook','*.xlsx')])
        if not path:return
        def do():
            preview=self.db.preview_attendance(self.event_id,path)
            if preview['issues']:
                messagebox.showerror('Attendance file needs corrections',
                    '\n'.join(preview['issues'][:7]) + ('\n…and more.' if len(preview['issues'])>7 else '') + '\n\nNo changes were made. Compare the listed cadets with Event Admin → Master Roster.',parent=self);return
            if preview['already_imported']:
                messagebox.showinfo('Already imported','This exact workbook was already imported. No changes made.',parent=self);return
            changes=len(preview['changes'])
            sample='\n'.join(f'#{cid}: {before} → {after}' for cid,before,after,_,_ in preview['changes'][:5])
            warnings=preview.get('warnings',[])
            company_note=('\n\n'+str(len(warnings))+' cadets were safely linked by exact name and class although the home company in the spreadsheet differs from the saved roster (for example, Regimental Staff).\n'+
                          '\n'.join(warnings[:2])+('\n…and more.' if len(warnings)>2 else '')) if warnings else ''
            frozen='\nA finalized formation exists; it will remain unchanged.' if self.db.formation_history(self.event_id) else ''
            unbound='\nThis workbook is a reusable template; results will be applied to the event currently selected in Formation Planner.' if preview.get('unbound') else ''
            if not messagebox.askyesno('Review attendance changes',
                 f'{preview["total"]} cadets matched. {changes} status/role changes found.\n\n{sample}'+
                 ('\n…and more.' if changes>5 else '')+company_note+frozen+unbound+'\n\nApply this import?',parent=self):return
            updated=self.db.apply_attendance(self.event_id,preview)
            self.refresh_all();self.status.set(f'Imported {updated} attendance changes. Only Attending cadets are included in company march-on.')
        action(self,do)


    def export_report(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',initialfile='Event_Attendance_Report.csv',filetypes=[('CSV','*.csv')])
        if path:action(self,lambda:self.db.export_event_report(self.event_id,path))

    def quick_change(self):
        def do():
            cid=self._lookup_cadet(self.cadet_lookup.get())
            status=self.quick_status.get()
            old=self.db.conn.execute('SELECT status FROM event_submissions WHERE event_id=? AND cadet_id=?',(self.event_id,cid)).fetchone()
            before=old[0] if old else 'Attending'
            if status==before:return
            if not messagebox.askyesno('Change status',f'Change from {before} to {status}?',parent=self):return
            self.db.set_submitted_status(self.event_id,cid,status)
            self.refresh_all()
        action(self,do)








    def refresh_heights(self):
        self.height_tree.delete(*self.height_tree.get_children())
        group=dict(self.db.conn.execute('SELECT key,name FROM formation_groups'))
        for cid,name,cls,co,h,ver in self.db.height_records():
            if self.only_missing.get() and h and ver not in ('Estimated','Unverified'):
                continue
            feet,inch=divmod(h,12) if h else (0,0)
            label=f'{feet}\'{inch:02}"' if h else 'Missing'
            self.height_tree.insert('','end',iid=str(cid),values=(name,cls,group.get(co,co),label,ver))

    def choose_height(self,*_):
        ids=self.height_tree.selection()
        if not ids:return
        cid=int(ids[0])
        row=self.db.conn.execute('SELECT height_inches,verification FROM cadet_heights WHERE cadet_id=?',(cid,)).fetchone()
        if not row:return
        h,ver=row;feet,inch=divmod(h,12)
        self.ft.set(str(feet) if h else '');self.inches.set(str(inch) if h else '');self.verified.set(ver)

    def edit_height(self):
        chosen=self.height_tree.selection()
        if not chosen:
            messagebox.showinfo('Select a cadet','Select a row in the height table.',parent=self);return
        def do():
            cid=int(chosen[0]);ft=self.ft.get().strip();inch=self.inches.get().strip()
            value=0 if not ft and not inch else int(ft or '0')*12+int(inch or '0')
            if inch and not 0<=int(inch)<12:raise ValueError('Inches must be between 0 and 11.')
            self.db.update_height(cid,value,self.verified.get())
            self.refresh_all();self.status.set('Height updated independently from attendance.')
        action(self,do)

    def export_heights(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.xlsx',initialfile='Height_Database.xlsx',filetypes=[('Excel workbook','*.xlsx')])
        if path:action(self,lambda:self.db.export_heights(path))

    def import_heights(self):
        path=filedialog.askopenfilename(parent=self,filetypes=[('Excel workbook','*.xlsx')])
        if not path:return
        def do():
            p=self.db.preview_height_import(path)
            if p['issues']:
                messagebox.showerror('Height file needs correction','\n'.join(p['issues'][:15]),parent=self);return
            if not messagebox.askyesno('Review height import',f'{p["total"]} records checked; {len(p["updates"])} changes.\nAttendance and home companies will not change. Apply?',parent=self):return
            count=self.db.apply_height_import(p)
            self.refresh_all();self.status.set(f'Updated {count} heights. Finalized formations unchanged.')
        action(self,do)

    def refresh_history(self):
        self.hist_tree.delete(*self.hist_tree.get_children())
        for revision,date in self.db.formation_history(self.event_id):
            self.hist_tree.insert('','end',iid=f'f:{revision}',values=('Formation',f'Revision {revision}',date,'Frozen'))
        for impid,created,file,changes in self.db.conn.execute('''SELECT id,imported_at,filename,changed
                                            FROM attendance_imports WHERE event_id=? ORDER BY id DESC''',(self.event_id,)):
            self.hist_tree.insert('','end',iid=f'i:{impid}',values=('Attendance import',file,created,changes))

    def restore_revision(self):
        items=self.hist_tree.selection()
        if not items or not items[0].startswith('f:'):
            messagebox.showinfo('Choose formation','Select a formation revision, not an import.',parent=self);return
        rev=int(items[0].split(':')[1])
        if not messagebox.askyesno('Restore historical formation',
             f'Copy revision {rev} to a NEW finalized revision? This will replace the displayed frozen version, but preserve all earlier revisions.',parent=self):return
        def do():
            new=self.db.restore_formation_snapshot(self.event_id,rev)
            self.refresh_all();self.status.set(f'Formation revision {rev} restored as revision {new}.')
        action(self,do)
