FORMATION PLANNER v5.2.6 | LEAN CLASSIC EDITION
================================================

The familiar v5.2.1 formation planner with direct eight-company-tab Excel
attendance imports, separate master roster/heights, and name autocomplete.

HOW TO START
1. Extract this ZIP completely.
2. Double-click START_WINDOWS.bat (Windows, Python 3 with tkinter).
3. Your existing database remains at %USERPROFILE%\FormationPlanner\roster.sqlite3.
   The app keeps its existing migration backups and saved formations.

ATTENDANCE (ONE WORKBOOK PER EVENT)
1. Select/create your event in the classic window.
2. Open Event Admin > Attendance > Export Corps Attendance.
3. Share that workbook. Cadets find their company tab and choose a dropdown:
   Attending (default), Excused, Medical Excusal, Pipe Band, Football,
   Game Support or Other. No explanations or approvals are needed.
4. Download the edited workbook and select Import Updated Attendance.
5. Confirm the changed statuses, then generate/print your formations.

ONLY Attending means march with the home company. ALL other choices mean
not in company march-on, regardless of reason; the label remains visible
in the Not Marching list and attendance report.

The included blank-ID Fall 2026 company-tab workbook also imports directly
when its cadets, classes and companies match your saved Master Roster.
Each row matches by name + class + company; ambiguous or missing records
are flagged instead of changed. New app exports include hidden cadet IDs.

DATA AND SAFETY
- Master Roster and Heights are separate from event attendance.
- Importing attendance cannot change names, companies, roles or heights.
- Reimporting the same file is idempotent.
- Already finalized formations remain saved as revisions.
- Archived official-excusal/approval records from older versions are not
  used; existing database tables are kept so upgrading does not erase data.
- The app runs locally and does not sync with SharePoint/OneDrive itself.

The program requires no pip installs or cloud services. One included
company-roster template is retained for the classic roster editor.

COMPANY MATCH FIX (v5.2.6)
- Corps-wide company tabs may list a cadet under their home company even if
  the older local Master Roster places them under Regimental Staff.
- When the exact company+class+name match fails, the importer accepts an
  exact name+class match ONLY when it identifies a single unique cadet.
- Such matches are displayed for review BEFORE changing any attendance.
- The master roster, company/role, and height are never changed by attendance.
- Unmatched or ambiguous records still prevent import, with names shown.
